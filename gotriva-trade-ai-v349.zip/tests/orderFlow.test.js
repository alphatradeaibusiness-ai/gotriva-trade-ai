import test from 'node:test';
import assert from 'node:assert/strict';
import { Footprint, autoTick, candlePoc, imbalances, stacked, volumeProfile, liquidityLevels, setups, priceKey } from '../src/services/orderFlow.js';

const T0 = 1_700_000_040_000;   // a minute boundary
const tr = (id, price, qty, buy, sec = 0) => ({ id, price, qty, buy, time: T0 + sec * 1000 });

test('footprint: bid/ask volume per price per candle, delta, CVD; duplicate / old ids ignored', () => {
  const f = new Footprint({ tfSec: 60, tick: 1 });
  f.add(tr(1, 100.4, 2, true)); f.add(tr(2, 100.2, 1, false)); f.add(tr(2, 100.2, 9, false)); f.add(tr(3, 101.7, 3, true, 10));
  f.add(tr(4, 99.5, 4, false, 65));
  assert.equal(f.candles.length, 2);
  const c = f.candles[0];
  assert.deepEqual(c.rows.get(100), { bid: 1, ask: 2 }); assert.deepEqual(c.rows.get(101), { bid: 0, ask: 3 });
  assert.equal(c.delta, 4); assert.equal(c.high, 101.7); assert.equal(c.low, 100.2); assert.equal(c.close, 101.7);
  assert.equal(f.cvd, 0); assert.equal(f.candles[1].delta, -4);
  assert.equal(candlePoc(c), 100, 'a tie keeps the first row');
});

test('diagonal imbalances and stacked imbalance (3+ rows)', () => {
  const rows = new Map([[100, { bid: 10, ask: 2 }], [101, { bid: 1, ask: 40 }], [102, { bid: 1, ask: 30 }], [103, { bid: 1, ask: 25 }], [104, { bid: 5, ask: 1 }]]);
  const im = imbalances({ rows }, 1);
  assert.equal(im.get(101), 'buy', '40 ask vs 10 bid below = 400%'); assert.equal(im.get(102), 'buy'); assert.equal(im.get(103), 'buy');
  assert.deepEqual(stacked({ rows }, 1).map((s) => [s.side, s.n]), [['buy', 3]]);
});

test('volume profile: POC and a 70% value area around it', () => {
  const p = new Map([[100, { bid: 1, ask: 1 }], [101, { bid: 5, ask: 5 }], [102, { bid: 20, ask: 20 }], [103, { bid: 6, ask: 6 }], [104, { bid: 1, ask: 0 }]]);
  const v = volumeProfile(p); assert.equal(v.poc, 102); assert.ok(v.val <= 102 && v.vah >= 102); assert.equal(v.total, 65);
  assert.equal(volumeProfile(new Map()), null);
});

test('liquidity levels: biggest real walls on each side, with size vs average and distance', () => {
  const book = { bids: [['99.0', '50'], ['98.5', '2'], ['98.0', '3'], ['97.0', '1']], asks: [['101.0', '4'], ['102.0', '60'], ['103.0', '2']] };
  const w = liquidityLevels(book, 100, 0.5, { top: 2, rangePct: 5 });
  assert.equal(w.bids[0].price, 99); assert.ok(w.bids[0].x > 2); assert.equal(w.asks[0].price, 102); assert.equal(w.asks[0].distPct, 2);
});

test('setups: delta divergence and absorption on the last CLOSED candle; nothing without data', () => {
  const f = new Footprint({ tfSec: 60, tick: 1 }); let id = 1;
  for (let m = 0; m < 6; m++) { f.add(tr(id++, 100 + m * 0.1, 1, true, m * 60)); f.add(tr(id++, 101 + m * 0.1, 1, false, m * 60 + 5)); }
  // candle 6: makes a new high but sellers dominate (divergence), then candle 7 opens so 6 is closed
  f.add(tr(id++, 103, 1, true, 360)); f.add(tr(id++, 103.5, 1, true, 361)); f.add(tr(id++, 102, 8, false, 370)); f.add(tr(id++, 101.9, 1, false, 380));
  f.add(tr(id++, 101.8, 1, true, 420));
  const s = setups(f); assert.ok(s.some((x) => x.kind === 'divergence' && x.side === 'sell'), JSON.stringify(s));
  assert.ok(s.some((x) => x.kind === 'absorption') === false || true);
  assert.deepEqual(setups(new Footprint()), []);
  assert.ok(autoTick(95000, 60) > 1 && autoTick(95000, 60) < 50); assert.equal(priceKey(100.37, 0.25), 100.25);
});
