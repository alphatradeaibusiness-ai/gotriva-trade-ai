import test from 'node:test';
import assert from 'node:assert/strict';
import { chooseRisk, levelsValid, trackSwing, evaluateSwing, swingSummary, RISK_POLICY, MIN_CONFIDENCE, SWING_TFS, pipsOf, isDuplicate, macd } from '../src/services/swingEngine.js';
import { lotFor, quoteToAccount, brokerMatch } from '../src/services/swingLot.js';
import { findInstrument } from '../src/config/instruments.js';

const EURUSD = findInstrument('EURUSD'); const XAU = findInstrument('XAUUSD'); const US30 = findInstrument('US30'); const JPY = findInstrument('USDJPY');

test('risk: chosen per trade from confidence, reduced by conditions, never above the policy / hard max, never 25 % automatically', () => {
  const vh = chooseRisk({ confidence: 92 }); const hi = chooseRisk({ confidence: 78 }); const md = chooseRisk({ confidence: 70 }); const lo = chooseRisk({ confidence: MIN_CONFIDENCE });
  assert.ok(vh.pct > hi.pct && hi.pct > md.pct && md.pct > lo.pct, JSON.stringify([vh, hi, md, lo]));
  assert.equal(chooseRisk({ confidence: MIN_CONFIDENCE - 1 }).tier, 'reject');
  assert.ok(chooseRisk({ confidence: 92, volRatio: 2 }).pct < vh.pct, 'high volatility lowers risk');
  assert.ok(chooseRisk({ confidence: 92, news: { level: 'high' } }).pct < chooseRisk({ confidence: 92, news: { level: 'soon' } }).pct);
  assert.equal(chooseRisk({ confidence: 100, maxPct: 25 }).policyMax, RISK_POLICY.HARD_MAX, 'a configured 25 % is clamped to the hard max');
  for (let c = 0; c <= 100; c += 1) for (const maxPct of [0.5, 2, 5, 25, 1000]) { const r = chooseRisk({ confidence: c, maxPct }); assert.ok(r.pct <= RISK_POLICY.HARD_MAX && r.pct < 25); }
  assert.ok(chooseRisk({ confidence: 95, openRiskPct: 2.9 }).pct <= 0.1 || chooseRisk({ confidence: 95, openRiskPct: 2.9 }).tier === 'reject', 'open exposure on the same market caps a new trade');
});

test('levels: stop on the losing side, targets ordered on the winning side (buy and sell)', () => {
  assert.equal(levelsValid({ direction: 'buy', entry: 100, stop: 99, targets: [101, 102, 103] }), true);
  assert.equal(levelsValid({ direction: 'buy', entry: 100, stop: 101, targets: [101, 102, 103] }), false);
  assert.equal(levelsValid({ direction: 'sell', entry: 100, stop: 101, targets: [99, 98, 97] }), true);
  assert.equal(levelsValid({ direction: 'sell', entry: 100, stop: 101, targets: [99, 99.5, 97] }), false);
});

const base = (o = {}) => ({ id: 'x', symbol: 'EURUSD', tf: '4h', direction: 'buy', entryType: 'limit', entry: 1.1, stop: 1.09, initialStop: 1.09, targets: [1.12, 1.13, 1.14], rr: [2, 3, 4], status: 'pending', createdAt: 1_000_000_000, expiresAt: 1_000_000_000 + 3600_000, hits: 0, pip: 0.0001, maxHoldUntil: 1_000_000_000 + 30 * 86400_000, ...o });
const bar = (tMs, low, high) => ({ time: Math.floor(tMs / 1000), open: (low + high) / 2, high, low, close: (low + high) / 2 });

test('tracking: limit fills → TP1 → stop to entry → closed at break-even; realized and floating kept apart', () => {
  const s = base(); const t = s.createdAt;
  let ev = trackSwing(s, [bar(t + 60_000, 1.101, 1.105)], { nowMs: t + 120_000, price: 1.104 });
  assert.equal(s.status, 'pending'); assert.equal(ev.length, 0); assert.equal(s.livePips, null);
  ev = trackSwing(s, [bar(t + 120_000, 1.0995, 1.103)], { nowMs: t + 180_000, price: 1.102 });
  assert.deepEqual(ev.map((e) => e.status), ['active']); assert.equal(s.fillPrice, 1.1); assert.equal(s.livePips, 20);
  ev = trackSwing(s, [bar(t + 180_000, 1.105, 1.1205)], { nowMs: t + 240_000, price: 1.118 });
  assert.deepEqual(ev.map((e) => e.status), ['tp1']); assert.ok(s.realizedR > 0 && s.floatingR > 0);
  ev = trackSwing(s, [bar(t + 240_000, 1.0999, 1.11)], { nowMs: t + 300_000, price: 1.1 });
  assert.equal(s.status, 'closed'); assert.equal(s.closeReason, 'breakeven_after_tp'); assert.equal(s.realizedR, 0.67);
  assert.equal(s.floatingR, 0);
});

test('tracking: sell market → stop loss = −1R; sell → TP3 = average of the three targets; pending expires → cancelled', () => {
  const t = 1_000_000_000;
  const s = base({ direction: 'sell', entryType: 'market', status: 'active', filledAt: t, entry: 1.1, stop: 1.11, initialStop: 1.11, targets: [1.08, 1.07, 1.06] });
  trackSwing(s, [bar(t + 60_000, 1.095, 1.111)], { nowMs: t + 120_000, price: 1.11 });
  assert.equal(s.status, 'sl'); assert.equal(s.realizedR, -1); assert.equal(s.realizedPips, -100);
  const w = base({ direction: 'sell', entryType: 'market', status: 'active', filledAt: t, entry: 1.1, stop: 1.11, initialStop: 1.11, targets: [1.08, 1.07, 1.06] });
  const ev = trackSwing(w, [bar(t + 60_000, 1.079, 1.1), bar(t + 120_000, 1.059, 1.08)], { nowMs: t + 180_000, price: 1.06 });
  assert.deepEqual(ev.map((e) => e.status), ['tp1', 'tp2', 'tp3']); assert.equal(w.realizedR, 3);
  const p = base();
  trackSwing(p, [bar(t + 7200_000, 1.101, 1.105)], { nowMs: t + 7300_000, price: 1.103 });
  assert.equal(p.status, 'cancelled'); assert.equal(p.closeReason, 'expired');
});

test('tracking: an old dip before TP1 never closes the trade at break-even when the candles are walked again', () => {
  const t = 1_000_000_000; const s = base({ status: 'active', filledAt: t, entryType: 'market' });
  const c1 = bar(t + 60_000, 1.0995, 1.105); const c2 = bar(t + 120_000, 1.105, 1.121);
  // c1 dips under the entry but not to the stop; c2 hits TP1. Walking [c1, c2] again later must keep the trade open.
  trackSwing(s, [c1, c2], { nowMs: t + 180_000 }); assert.equal(s.status, 'tp1');
  trackSwing(s, [c1, c2, bar(t + 180_000, 1.11, 1.115)], { nowMs: t + 240_000 }); assert.equal(s.status, 'tp1');
});

test('lot size: forex USD account, JPY quote converted with the live rate, gold standard contract, broker spec wins, indices need a broker spec', () => {
  const acc = { amount: 10000, currency: 'USD', basis: 'equity', source: 'mt5' };
  const eu = lotFor({ symbol: 'EURUSD', entry: 1.1, stop: 1.095, riskPct: 1 }, acc, null, EURUSD, {});
  assert.equal(eu.ok, true); assert.equal(eu.lots, 0.2); assert.equal(eu.riskAmount, 100); assert.equal(eu.specSource, 'standard');   // 50 pips × $10 = $500 per lot
  const uj = lotFor({ symbol: 'USDJPY', entry: 150, stop: 149.5, riskPct: 1 }, acc, null, JPY, { USDJPY: 150 });
  assert.equal(uj.ok, true); assert.equal(uj.lots, 0.3);   // 0.5 JPY × 100 000 / 150 = $333.33 per lot → 100 / 333.3 = 0.30
  assert.equal(lotFor({ symbol: 'USDJPY', entry: 150, stop: 149.5, riskPct: 1 }, acc, null, JPY, {}).reason, 'no_conversion_rate');
  const xau = lotFor({ symbol: 'XAUUSD', entry: 4000, stop: 3980, riskPct: 0.5 }, acc, null, XAU, {});
  assert.equal(xau.lots, 0.02);   // 20 × 100 = $2000 per lot → $50 / 2000 = 0.025 → 0.02 (rounded DOWN)
  const br = lotFor({ symbol: 'XAUUSD', entry: 4000, stop: 3980, riskPct: 0.5 }, acc, { tickSize: 0.01, tickValue: 1, volMin: 0.01, volStep: 0.01, volMax: 50 }, XAU, {});
  assert.equal(br.specSource, 'broker'); assert.equal(br.lots, 0.02);
  assert.equal(lotFor({ symbol: 'US30', entry: 45000, stop: 44800, riskPct: 1 }, acc, null, US30, {}).reason, 'no_contract_spec');
  assert.equal(lotFor({ symbol: 'US30', entry: 45000, stop: 44800, riskPct: 1 }, acc, { tickSize: 1, tickValue: 1, volMin: 0.1, volStep: 0.1, volMax: 100 }, US30, {}).lots, 0.5);
  const tiny = lotFor({ symbol: 'XAUUSD', entry: 4000, stop: 3900, riskPct: 0.1 }, { amount: 500, currency: 'USD' }, null, XAU, {});
  assert.equal(tiny.belowMin, true); assert.equal(tiny.lots, 0); assert.ok(tiny.minLotRiskPct > 0.1);
  assert.equal(lotFor({ symbol: 'EURUSD', entry: 1.1, stop: 1.09, riskPct: 1 }, null, null, EURUSD, {}).reason, 'no_account');
  assert.equal(quoteToAccount('USD', 'EUR', { EURUSD: 1.25 }), 0.8); assert.equal(quoteToAccount('JPY', 'EUR', { USDJPY: 150, EURUSD: 1.5 }), 1 / 150 / 1.5);
  assert.equal(brokerMatch('XAUUSD.m', 'XAUUSD'), true); assert.equal(brokerMatch('GOLD', 'XAUUSD'), true); assert.equal(brokerMatch('USTEC', 'US100'), true); assert.equal(brokerMatch('EURUSDJPY', 'EURUSD'), false);
});

test('pips / points and the duplicate guard', () => {
  assert.equal(pipsOf(0.005, EURUSD), 50); assert.equal(pipsOf(2, XAU), 20); assert.equal(pipsOf(150, US30), 150);
  const live = [{ symbol: 'EURUSD', direction: 'buy', tf: '1h', status: 'active', createdAt: 0 }];
  assert.equal(isDuplicate(live, { symbol: 'EURUSD', direction: 'buy', tf: '4h' }, 14400, 1e12), true);
  assert.equal(isDuplicate(live, { symbol: 'EURUSD', direction: 'sell', tf: '4h' }, 14400, 1e12), false);
  const m = macd(Array.from({ length: 100 }, (_, i) => 100 + i)); assert.ok(m.hist.at(-1) != null);
});

test('evaluate: only H1 / H4 / Daily, never demo or stale data, never a forming candle', () => {
  const now = 1_700_000_000_000; const market = { id: 'EURUSD', symbol: 'EURUSD' };
  assert.equal(evaluateSwing({ market, inst: EURUSD, tf: '15m', ds: { mode: 'live', candles: [] }, nowMs: now }).reason, 'timeframe_not_swing');
  assert.equal(evaluateSwing({ market, inst: EURUSD, tf: '4h', ds: { mode: 'demo', candles: [] }, nowMs: now }).reason, 'demo_data');
  const sec = 14400; const end = Math.floor(now / 1000 / sec) * sec;
  const old = Array.from({ length: 260 }, (_, i) => ({ time: end - (260 - i) * sec - 10 * sec, open: 1, high: 1.01, low: 0.99, close: 1, volume: 1 }));
  assert.equal(evaluateSwing({ market, inst: EURUSD, tf: '4h', ds: { mode: 'live', candles: old }, quote: { price: 1, at: now }, nowMs: now }).reason, 'no_fresh_candle');
  assert.deepEqual(SWING_TFS, ['1h', '4h', '1D']);
});

test('evaluate: every signal produced over many real-shaped windows is valid (levels, risk cap, threshold, live quote)', () => {
  let seed = 7; const rnd = () => { seed = (seed * 16807) % 2147483647; return seed / 2147483647; };
  const sec = 3600; let made = 0; let checked = 0;
  for (let run = 0; run < 40; run++) {
    const n = 400; const now = 1_760_000_000_000 + run * 1e9; const end = Math.floor(now / 1000 / sec) * sec;
    let p = 1.1; const drift = (rnd() - 0.5) * 0.0006; const cs = [];
    for (let i = 0; i < n; i++) { const o = p; p = Math.max(0.5, p + drift + (rnd() - 0.5) * 0.004); const h = Math.max(o, p) + rnd() * 0.0015; const l = Math.min(o, p) - rnd() * 0.0015; cs.push({ time: end - (n - i) * sec, open: o, high: h, low: l, close: p, volume: 100 + rnd() * 50 }); }
    const r = evaluateSwing({ market: { id: 'EURUSD', symbol: 'EURUSD' }, inst: EURUSD, tf: '1h', ds: { mode: 'live', candles: cs }, quote: { price: p, at: now }, nowMs: now, signals: [] });
    checked++;
    if (!r.signal) continue; made++;
    const s = r.signal;
    assert.ok(levelsValid({ direction: s.direction, entry: s.entry, stop: s.stop, targets: s.targets }), JSON.stringify(s));
    assert.ok(s.confidence >= MIN_CONFIDENCE && s.riskPct > 0 && s.riskPct <= RISK_POLICY.SAFE_MAX);
    assert.ok(['market', 'limit'].includes(s.entryType)); assert.equal(s.status, s.entryType === 'market' ? 'active' : 'pending');
    if (s.entryType === 'limit') assert.ok(s.direction === 'buy' ? s.entry < s.price : s.entry > s.price, 'a limit sits on the right side of the live price');
  }
  assert.equal(checked, 40);
  console.log(`# swing property test: ${made} signals out of ${checked} windows`);
});

test('summary: only recorded, closed trades count; cancelled limits are not losses', () => {
  const sigs = [
    { symbol: 'EURUSD', tf: '4h', strategy: 's', status: 'tp3', filledAt: 1, realizedR: 3, realizedPips: 300, rr: [2, 3, 4], riskPct: 1, riskTier: 'high' },
    { symbol: 'EURUSD', tf: '4h', strategy: 's', status: 'sl', filledAt: 1, realizedR: -1, realizedPips: -100, rr: [2, 3, 4], riskPct: 0.6, riskTier: 'medium' },
    { symbol: 'XAUUSD', tf: '1D', strategy: 's', status: 'cancelled', filledAt: null, rr: [2, 3, 4], riskPct: 0.3, riskTier: 'low' },
    { symbol: 'XAUUSD', tf: '1h', strategy: 's', status: 'active', filledAt: 1, rr: [2, 3, 5], riskPct: 1, riskTier: 'high' },
  ];
  const s = swingSummary(sigs);
  assert.equal(s.completed, 2); assert.equal(s.winRate, 0.5); assert.equal(s.realizedPips, 200); assert.equal(s.cancelled, 1); assert.equal(s.active, 1);
  assert.equal(s.byMarket.EURUSD.n, 2); assert.equal(s.riskTiers.high, 2); assert.equal(swingSummary([]).winRate, null);
});
