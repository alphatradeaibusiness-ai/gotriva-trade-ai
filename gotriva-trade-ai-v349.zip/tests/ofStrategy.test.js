import test from 'node:test';
import assert from 'node:assert/strict';
import { prepare, signalAt, planFor, simulate, backtest, OF_RULES } from '../src/services/ofStrategy.js';

const base = (n) => Array.from({ length: n }, (_, i) => { const c = 100 + Math.sin(i / 6) * 1.2; return { time: i * 300, open: c, high: c + 0.6, low: c - 0.6, close: c + 0.05, volume: 100, buy: 50 }; });

test('setup A: a sweep of the 20-bar low on big volume with heavy selling that closes high → BUY; stop below the low', () => {
  const cs = base(80); const i = 70; const lo = Math.min(...cs.slice(50, 70).map((c) => c.low));
  cs[i] = { time: i * 300, open: lo + 0.3, high: lo + 1.2, low: lo - 1, close: lo + 1, volume: 400, buy: 120 };   // delta = -160 (-40%)
  const s = signalAt(prepare(cs), i); assert.equal(s?.setup, 'A'); assert.equal(s.side, 'buy'); assert.ok(s.stop < cs[i].low);
});

test('setup B: new high with negative delta, red close and falling CVD → SELL', () => {
  const cs = base(80); const i = 70; const hi = Math.max(...cs.slice(50, 70).map((c) => c.high));
  for (let k = 65; k < 70; k++) cs[k] = { ...cs[k], buy: 40 };   // CVD falling
  cs[i] = { time: i * 300, open: hi, high: hi + 1, low: hi - 0.8, close: hi - 0.5, volume: 120, buy: 50 };
  const s = signalAt(prepare(cs), i); assert.equal(s?.setup, 'B'); assert.equal(s.side, 'sell'); assert.ok(s.stop > cs[i].high);
});

test('no signal on quiet bars; planFor rejects a stop that is too tight or too wide', () => {
  const cs = base(80); const P = prepare(cs);
  for (let i = 0; i < 80; i++) assert.equal(signalAt(P, i)?.setup === 'A', false);
  assert.equal(planFor({ side: 'buy', stop: 99.999 }, 100, 1), null, 'too tight');
  assert.equal(planFor({ side: 'buy', stop: 90 }, 100, 1), null, 'too wide');
  assert.ok(planFor({ side: 'buy', stop: 99 }, 100, 1).tp2 === 103);
});

test('simulate: stop first when a bar hits both; half at TP1 then stop to entry; TP2 = 0.75 + 1.5 = 2.25R', () => {
  const plan = { entry: 100, stop: 99, tp1: 101.5, tp2: 103, risk: 1 };
  assert.equal(simulate([{ high: 104, low: 98, close: 100 }], 0, 'buy', plan).outcome, 'sl');
  const r = simulate([{ high: 101.6, low: 99.5, close: 101 }, { high: 103.2, low: 100.5, close: 103 }], 0, 'buy', plan);
  assert.equal(r.outcome, 'tp2'); assert.equal(r.r, 2.25);
  const be = simulate([{ high: 101.6, low: 99.5, close: 101 }, { high: 101, low: 99.9, close: 100 }], 0, 'buy', plan);
  assert.equal(be.outcome, 'tp1_be'); assert.equal(be.r, 0.75);
});

test('backtest: one trade at a time, fees charged, stats add up', () => {
  const cs = base(400);
  for (const i of [100, 200, 300]) { const lo = Math.min(...cs.slice(i - 20, i).map((c) => c.low)); cs[i] = { time: i * 300, open: lo + 0.3, high: lo + 1.2, low: lo - 1, close: lo + 1, volume: 400, buy: 120 }; }
  const bt = backtest(cs, { feePct: 0.04 });
  assert.ok(bt.trades.length >= 3); assert.ok(bt.trades.every((t) => t.fee > 0));
  const s = bt.stats.all; assert.equal(s.n, bt.trades.length); assert.equal(s.curve.length, s.n);
  assert.equal(+bt.trades.reduce((a, t) => a + t.r, 0).toFixed(2), s.totalR);
  for (let k = 1; k < bt.trades.length; k++) assert.ok(bt.trades[k].time > bt.trades[k - 1].time);
});
