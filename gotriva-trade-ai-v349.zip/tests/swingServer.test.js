import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { createSwingService, alertText } from '../server/swing.js';

const NOW = Date.UTC(2026, 10, 16, 12);
function setup({ enforce = true, plans = {}, quota } = {}) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'sw-')); const wdir = fs.mkdtempSync(path.join(os.tmpdir(), 'sww-'));
  const sig = (k, extra = {}) => ({ id: `s${k}`, symbol: 'EURUSD', name: 'EURUSD', tf: '4h', direction: 'buy', entryType: 'limit', entry: 1.1, stop: 1.095, initialStop: 1.095, targets: [1.11, 1.12, 1.13], rr: [2, 4, 6], unit: 'pips', pip: 0.0001, confidence: 80, riskPct: 1, riskTier: 'high', riskReasons: ['tier_high'], status: 'pending', createdAt: NOW - (10 - k) * 3600_000, strategy: 'swing_smc_ict', ...extra });
  const signals = Array.from({ length: 5 }, (_, k) => sig(k));
  fs.writeFileSync(path.join(wdir, 'swing-signals.json'), JSON.stringify({ signals, markets: {}, rates: {}, lastScan: NOW, lastTrack: NOW }));
  const delivered = [];
  const svc = createSwingService({
    dataDir: dir, workerDir: () => wdir, now: () => NOW, log: {},
    growth: { members: () => [{ uid: 'paid', email: 'p@x', lang: 'en' }, { uid: 'free', email: 'f@x', lang: 'ar' }, { uid: 'own', email: 'owner@x', lang: 'ar' }], deliver: async (uid, n) => { delivered.push({ uid, tag: n.tag, body: n.body }); } },
    ent: { enforce, planOf: (uid) => plans[uid] || null },
    mt5: { list: (uid) => ({ links: uid === 'paid' ? [{ connected: true, terminal: { equity: 10000, balance: 9000, currency: 'USD', specs: [{ name: 'EURUSD.m', tickSize: 0.00001, tickValue: 1, volMin: 0.01, volStep: 0.01, volMax: 50 }] } }] : [] }) },
    isOwnerEmail: (u) => u.email === 'owner@x', channelAccess: { channelOnly: (uid) => uid === 'chan' },
  });
  return { svc, wdir, delivered, signals };
}

test('swing feed: plan rules decided on the server; channel-only and free are refused; owners always pass', () => {
  const { svc } = setup({ plans: { paid: 'monthly' } });
  assert.equal(svc.feed({ uid: 'free', email: 'f@x' }).body.code, 'plan_upgrade_required');
  assert.equal(svc.feed({ uid: 'chan', email: 'c@x' }).body.code, 'platform_plan_required');
  assert.equal(svc.feed({ uid: 'own', email: 'owner@x' }).status, 200);
  assert.equal(svc.feed({ uid: 'paid', email: 'p@x' }).status, 200);
});

test('swing feed: the lot is computed for each member from THEIR linked MT5 account with the broker spec; others see none', () => {
  const { svc } = setup({ plans: { paid: 'monthly' } });
  const p = svc.feed({ uid: 'paid', email: 'p@x' }).body;
  const s = p.signals[0];
  assert.equal(s.lot.ok, true); assert.equal(s.lot.specSource, 'broker'); assert.equal(s.lot.lots, 0.2); assert.equal(s.brokerSymbol, 'EURUSD.m');   // 1% of 10 000 / (500 ticks × 1)
  assert.equal(p.account.source, 'mt5'); assert.equal(p.account.amount, 10000);
  const o = svc.feed({ uid: 'own', email: 'owner@x' }).body;
  assert.equal(o.signals[0].lot.ok, false); assert.equal(o.signals[0].lot.reason, 'no_account'); assert.equal(o.account, null);
  assert.equal(svc.setPrefs('own', { manual: 5000, currency: 'usd' }).ok, true);
  const o2 = svc.feed({ uid: 'own', email: 'owner@x' }).body;
  assert.equal(o2.account.source, 'manual'); assert.equal(o2.signals[0].lot.lots, 0.1); assert.equal(o2.signals[0].lot.specSource, 'standard');
  assert.equal(svc.setPrefs('own', { manual: -1, currency: 'USD' }).error, 'bad_input');
});

test('swing feed: the plan allowance is enforced by the server (levels withheld above it), not by the page', async () => {
  const { svc } = setup({ plans: { paid: 'monthly' } });
  const { TIERS } = await import('../src/config/entitlements.js');
  const q = TIERS.monthly.signalsPerMonth;
  assert.ok(q >= 5, 'the test assumes a quota of at least five');
  const b = svc.feed({ uid: 'paid', email: 'p@x' }).body; assert.equal(b.signals.filter((s) => s.locked).length, 0); assert.equal(b.access.quota, q);
  // simulate a plan with a smaller allowance by hand
  TIERS.monthly.signalsPerMonth = 2;
  try {
    const b2 = svc.feed({ uid: 'paid', email: 'p@x' }).body;
    const locked = b2.signals.filter((s) => s.locked);
    assert.equal(locked.length, 3); assert.equal(locked[0].entry, undefined, 'no levels in a locked card');
    assert.equal(b2.signals.filter((s) => !s.locked).map((s) => s.id).sort().join(), 's0,s1', 'the first two of the month stay open');
  } finally { TIERS.monthly.signalsPerMonth = q; }
});

test('swing announcements: once per event per member with access; status changes announced once; no repeats', async () => {
  const { svc, wdir, delivered, signals } = setup({ plans: { paid: 'monthly' } });
  assert.equal(svc.tick(), 0, 'recommendations older than the first start are never announced again');
  signals.forEach((x, k) => { x.id = `n${k}`; x.createdAt = NOW + k; }); fs.writeFileSync(path.join(wdir, 'swing-signals.json'), JSON.stringify({ signals }));
  await new Promise((r) => setTimeout(r, 15));
  assert.equal(svc.tick(), 5); await new Promise((r) => setTimeout(r, 20));
  const users = new Set(delivered.map((d) => d.uid)); assert.deepEqual([...users].sort(), ['own', 'paid'], 'the free member gets nothing');
  assert.equal(delivered.filter((d) => d.uid === 'paid').length, 5);
  assert.match(delivered.find((d) => d.uid === 'paid').body, /0\.2 lot/, 'the alert carries the member\'s own lot');
  assert.equal(svc.tick(), 0, 'nothing new → nothing sent');
  signals[0].status = 'tp1'; fs.writeFileSync(path.join(wdir, 'swing-signals.json'), JSON.stringify({ signals }));
  await new Promise((r) => setTimeout(r, 15));
  assert.equal(svc.tick(), 1); await new Promise((r) => setTimeout(r, 20));
  assert.equal(delivered.filter((d) => d.tag === 'n0:tp1').length, 2);
  assert.equal(svc.tick(), 0);
  assert.match(alertText(signals[0], 'tp1', 'en'), /TP1 hit/);
});
