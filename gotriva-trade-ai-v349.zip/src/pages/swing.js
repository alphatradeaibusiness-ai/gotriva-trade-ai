// Swing Pulse Pro (v346) — the page of the independent swing channel (H1 / H4 / Daily). Read-only view of /api/swing/feed:
// open, pending and finished recommendations, the AI confidence and the AI-chosen risk of each one, the member's own lot size
// (computed by the server from their account), live tracking, the channel's own recorded results and the state of each market.
import { h, esc } from '../utils/dom.js';
import { getLang } from '../i18n/index.js';
import { icons, assetIcon } from '../components/icons.js';
import { getInstrument } from '../config/instruments.js';
import { apiRequest } from '../services/ai/gateway.js';
import { fmtTz, tzLabel } from '../services/aiSignalUtil.js';
import { toast } from '../components/ui.js';
import '../styles/swing.css';

const POLL_MS = 15_000;
const LIVE = ['pending', 'active', 'tp1', 'tp2'];

export function renderSwing() {
  const AR = getLang() === 'ar'; const L = (ar, en) => (AR ? ar : en);
  const TF = { '1h': 'H1', '4h': 'H4', '1D': 'D1' };
  const ST = {
    pending: [L('معلّقة', 'PENDING'), 'st-pending'], active: [L('فعّالة', 'ACTIVE'), 'st-active'], tp1: ['TP1 HIT', 'st-tp'], tp2: ['TP2 HIT', 'st-tp'], tp3: ['TP3 HIT', 'st-win'],
    sl: [L('ضرب الوقف', 'STOP LOSS HIT'), 'st-loss'], closed: [L('مسكّرة', 'CLOSED'), 'st-closed'], cancelled: [L('ملغاة', 'CANCELLED'), 'st-closed'],
  };
  const TIER = { very_high: L('عالية جداً', 'Very high'), high: L('عالية', 'High'), medium: L('متوسطة', 'Medium'), low: L('منخفضة', 'Low') };
  const RISKWHY = { tier_very_high: L('ثقة عالية جداً', 'very high confidence'), tier_high: L('ثقة عالية', 'high confidence'), tier_medium: L('ثقة متوسطة', 'medium confidence'), tier_low: L('ثقة منخفضة', 'low confidence'),
    high_volatility: L('تقلب أعلى من الطبيعي ← مخاطرة أقل', 'above-normal volatility → lower risk'), news_soon: L('خبر قوي خلال 24 ساعة ← مخاطرة أقل', 'high-impact news within 24 h → lower risk'), news_now: L('خبر قوي قريب جداً ← مخاطرة أقل بكثير', 'high-impact news very close → much lower risk'),
    wide_stop: L('وقف بعيد ← مخاطرة أقل', 'wide stop → lower risk'), exposure_cap: L('في صفقة مفتوحة على نفس السوق ← قلّلنا', 'already exposed on this market → reduced'), policy_cap: L('سقف سياسة المخاطرة', 'risk-policy ceiling') };
  const CONF = { bias: L('اتجاه الفريمات الأعلى', 'Higher-timeframe bias'), structure: L('هيكل السوق', 'Market structure'), sweep: L('سحب سيولة', 'Liquidity sweep'), mss: L('كسر هيكل (BOS/CHoCH)', 'Structure shift (BOS/CHoCH)'), pd: L('منطقة خصم/علاوة صحيحة', 'Discount / premium'), ote: 'OTE / Fibonacci',
    poi_ob: 'Order Block', poi_fvg: 'Fair Value Gap', poi_bb: 'Breaker Block', poi_ifvg: 'Inverse FVG', ema_stack: 'EMA 20/50/100/200', ema200: 'EMA 200', rsi: 'RSI', rsi_turn: L('زخم RSI', 'RSI momentum'), macd: 'MACD', volume: L('حجم تداول داعم', 'Volume confirmation') };
  const LOTWHY = { no_account: L('اربط حساب ميتاتريدر 5 أو اكتب رصيدك تحت حتى نحسب اللوت.', 'Link MetaTrader 5 or enter your balance below to size the lot.'), no_contract_spec: L('مواصفات العقد بتختلف حسب الوسيط: اربط ميتاتريدر 5 (Expert Advisor 1.10) حتى ينحسب اللوت بدقة.', 'Contract specs differ by broker: link MetaTrader 5 (Expert Advisor 1.10) for an exact lot.'),
    no_conversion_rate: L('ما في سعر صرف حي لعملة حسابك هلّق.', 'No live conversion rate for your account currency right now.'), bad_levels: '—', no_risk: '—' };
  const MSTATE = { live: [L('حيّ', 'Live'), 'm-live'], closed: [L('السوق مسكّر', 'Market closed'), 'm-closed'], stale: [L('بيانات متأخرة', 'Delayed data'), 'm-stale'], unavailable: [L('ما في بيانات حقيقية', 'No real data'), 'm-off'], insufficient: [L('بيانات غير كافية', 'Not enough data'), 'm-stale'], pending: [L('بانتظار أول فحص', 'Waiting for first scan'), 'm-stale'] };
  const num = (v, p) => (Number.isFinite(v) ? Number(v).toFixed(p ?? 2) : '—');
  const signed = (v, d = 1) => (Number.isFinite(v) ? `${v > 0 ? '+' : ''}${Number(v).toFixed(d)}` : '—');

  const el = h(`<section class="subpage swing page-enter" dir="${AR ? 'rtl' : 'ltr'}">
    <header class="sw-hero">
      <div class="sw-brand"><span class="sw-logo" aria-hidden="true">${icons.wave || ''}</span><div><h1>Swing Pulse <b>Pro</b></h1>
      <p class="muted">${esc(L('قناة سوينغ مستقلة على H1 و H4 واليومي: SMC و ICT مع تأكيد فني. الذكاء الاصطناعي بيختار نسبة المخاطرة لكل توصية لحالها، والموقع بيحسب اللوت من حسابك.', 'An independent swing channel on H1, H4 and Daily: SMC & ICT with technical confirmation. The AI chooses the risk of every recommendation on its own, and the lot is sized from your account.'))}</p></div></div>
      <div class="sw-live" data-live></div>
    </header>
    <div class="sw-kpis" data-kpis></div>
    <nav class="sw-tabs" role="tablist" data-tabs>
      <button type="button" role="tab" data-tab="open" aria-selected="true">${esc(L('مفتوحة', 'Active'))}<i data-n="open"></i></button>
      <button type="button" role="tab" data-tab="pending" aria-selected="false">${esc(L('معلّقة', 'Pending'))}<i data-n="pending"></i></button>
      <button type="button" role="tab" data-tab="done" aria-selected="false">${esc(L('منتهية', 'Completed'))}<i data-n="done"></i></button>
      <button type="button" role="tab" data-tab="stats" aria-selected="false">${esc(L('الأداء', 'Performance'))}</button>
      <button type="button" role="tab" data-tab="markets" aria-selected="false">${esc(L('الأسواق', 'Markets'))}</button>
      <button type="button" role="tab" data-tab="account" aria-selected="false">${esc(L('حسابي واللوت', 'My account & lot'))}</button>
    </nav>
    <div class="sw-panel" data-panel></div>
    <p class="sw-foot muted" data-foot></p>
  </section>`);

  const openWhy = new Set(); let D = null; let tab = 'open'; let stop = false; let timer = 0; let locked = null;

  // v346b card in the reference style: symbol + "Swing · H1" + "SELL LIMIT" pills, a status chip, the setup line and the age,
  // ENTRY / SL / TP1 / TP2 / TP3 with the pips to each, then the member's own lot and money (floating and banked at targets).
  const ago = (ms) => { const m = Math.max(0, Math.round((Date.now() - ms) / 60000)); if (m < 60) return L(`قبل ${m} د`, `${m}m ago`); const hh = Math.round(m / 60); if (hh < 48) return L(`قبل ${hh} س`, `${hh}h ago`); return L(`قبل ${Math.round(hh / 24)} يوم`, `${Math.round(hh / 24)}d ago`); };
  const CHIP = { pending: L('بانتظار الدخول', 'Waiting for entry'), active: L('فعّالة', 'Active'), tp1: L('ضرب <bdi>TP1</bdi>، ماشي لـ <bdi>TP2</bdi>', 'TP1 hit, riding to TP2'), tp2: L('ضرب <bdi>TP2</bdi>، ماشي لـ <bdi>TP3</bdi>', 'TP2 hit, riding to TP3'), tp3: L('ضرب <bdi>TP3</bdi> كاملة', 'TP3 hit, all targets'), sl: L('ضرب الوقف', 'Stop loss hit'), closed: L('مسكّرة', 'Closed'), cancelled: L('ملغاة', 'Cancelled') };
  const SETUP = { poi_ob: 'Order Block', poi_fvg: 'Fair Value Gap', poi_bb: 'Breaker Block', poi_ifvg: 'Inverse FVG', sweep: L('سحب سيولة', 'liquidity sweep'), mss: 'BOS / CHoCH', ote: 'OTE' };
  const money = (v, cur) => (Number.isFinite(v) ? `${v >= 0 ? '+' : '−'}${cur === 'USD' || !cur ? '$' : ''}${Math.abs(v).toFixed(2)}${cur && cur !== 'USD' ? ` ${cur}` : ''}` : '—');
  const moneyOf = (s) => { const l = s.lot; if (!l?.ok || !(l.lots > 0) || !Number.isFinite(l.riskActual)) return null; const R = l.riskActual; return { cur: l.currency || 'USD', now: R * ((s.floatingR || 0) + (s.realizedR || 0)), banked: s.realizedR != null ? R * s.realizedR : null, risk: R }; };

  const card = (s) => {
    if (s.locked) return `<article class="swc is-locked"><div class="swc-top"><b class="swc-sym" dir="ltr">${esc(s.name)}</b><span class="swc-pill" dir="ltr">Swing · ${esc(TF[s.tf] || s.tf)}</span></div><p class="muted">${esc(L('خلصت توصيات باقتك لهالشهر. رقّي باقتك حتى تشوف هالتوصية.', 'Your plan\'s recommendations for this month are used up. Upgrade to see this one.'))}</p><a class="btn btn-sm btn-primary" href="#/app/pricing">${esc(L('الباقات', 'Plans'))}</a></article>`;
    const inst = getInstrument(s.symbol); const prec = s.precision ?? inst?.precision ?? 5; const long = s.direction === 'buy';
    const unit = s.unit === 'points' ? L('نقطة', 'pts') : 'pips';
    const live = LIVE.includes(s.status);
    const chipCls = s.status === 'sl' ? 'bad' : ['tp1', 'tp2', 'tp3'].includes(s.status) ? 'good' : s.status === 'pending' ? 'wait' : s.status === 'active' ? 'live' : 'off';
    const setup = (s.confirmations || []).map((c) => SETUP[c]).filter(Boolean).slice(0, 2).join(' + ') || L('سوينغ SMC / ICT', 'SMC / ICT swing');
    const lv = (k, label, v, pips, cls = '') => `<div class="swc-lv ${cls}"><dt>${label}</dt><dd class="mono">${num(v, prec)}</dd>${pips == null ? '' : `<small class="mono">${pips}</small>`}</div>`;
    const pp = (v, sign) => (Number.isFinite(v) ? `${sign}${Math.abs(v).toFixed(1)} ${unit}` : null);
    const m = moneyOf(s); const lot = s.lot;
    const mine = live ? (lot?.ok && lot.lots > 0
      ? `<span class="swc-plan">${esc(L('بحسابك', 'In your plan'))} · <b><bdi>${lot.lots} lot</bdi></b> · ${esc(L('مخاطرة', 'risk'))} <bdi>${money(m?.risk ?? lot.riskActual, lot.currency).replace('+', '')}</bdi></span>`
      : `<span class="swc-plan is-na">${esc(LOTWHY[lot?.reason] || LOTWHY.no_account)}</span>`) : '';
    const pipsNow = s.status === 'pending' ? null : live ? s.livePips : s.realizedPips;
    const nowLine = s.status === 'pending'
      ? `<span>${esc(L('بعد عن الدخول', 'To entry'))} <b class="mono" dir="ltr">${num(Math.abs((s.price ?? s.entry) - s.entry) / (s.pip || 1), 1)} ${unit}</b></span>`
      : `<span>${esc(live ? L('هلّق', 'Now') : L('النتيجة', 'Result'))} <b class="mono ${(pipsNow ?? 0) >= 0 ? 'up' : 'down'}" dir="ltr">${signed(pipsNow)} ${unit}${m ? ` ${money(live ? m.now : m.banked ?? 0, m.cur)}` : ''}</b>${m && live && m.banked ? ` · <bdi>${money(m.banked, m.cur).replace('+', '')}</bdi> ${L(`انحجزت عند <bdi>TP${s.hits}</bdi>`, `banked at TP${s.hits}`)}` : ''}</span>`;
    return `<article class="swc ${long ? 'is-buy' : 'is-sell'} ${live ? 'is-live' : 'is-done'}" data-id="${esc(s.id)}">
      <div class="swc-top">
        <b class="swc-sym" dir="ltr">${esc(s.name)}</b>
        <span class="swc-pill" dir="ltr">Swing · ${esc(TF[s.tf] || s.tf)}</span>
        <span class="swc-side ${long ? 'buy' : 'sell'}" dir="ltr">${long ? 'BUY' : 'SELL'} ${s.entryType === 'limit' ? 'LIMIT' : 'MARKET'}</span>
        <button type="button" class="swc-doc" data-why aria-label="${esc(L('تفاصيل التحليل', 'Analysis details'))}"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M7 3h7l5 5v13H7z"/><path d="M14 3v5h5M10 13h6M10 17h6"/></svg></button>
      </div>
      <div class="swc-row"><span class="swc-chip ${chipCls}">${CHIP[s.status] || esc(s.status)}</span><span class="swc-ai">${esc(L('ثقة AI', 'AI'))} <bdi>${s.confidence}%</bdi> · ${esc(L('مخاطرة', 'risk'))} <bdi>${s.riskPct}%</bdi></span></div>
      <div class="swc-row swc-sub"><span>${esc(setup)}</span><span>${esc(ago(s.createdAt))}</span></div>
      <dl class="swc-lvs" dir="ltr">
        ${lv('e', 'ENTRY', s.entry, null)}
        ${lv('sl', s.stop !== s.initialStop ? 'SL → BE' : 'SL', s.initialStop, pp(s.pipsTo?.stop, '−'), `sl ${s.stop !== s.initialStop ? 'be' : ''}`)}
        ${s.targets.map((t, k) => lv(`t${k}`, `TP${k + 1}`, t, pp(s.pipsTo?.targets?.[k], '+'), `tp ${s.hits > k ? 'hit' : ''}`)).join('')}
      </dl>
      <div class="swc-track" style="--p:${(() => { const px = Number.isFinite(s.price) ? s.price : s.entry; return Math.max(0, Math.min(1, (px - s.initialStop) / (s.targets[2] - s.initialStop))); })()}" aria-hidden="true"><i></i></div>
      <div class="swc-foot">${mine}<div class="swc-now">${nowLine}</div></div>
      <div class="swc-why" hidden>
        <p>${esc(L('سبب نسبة المخاطرة:', 'Risk chosen because:'))} ${esc((s.riskReasons || []).map((r) => RISKWHY[r] || r).join(' · '))} · ${esc(TIER[s.riskTier] || '')}${s.riskAboveSafe ? ` · <b>${esc(L('أعلى من سياسة الأمان', 'above the safe policy'))}</b>` : ''}</p>
        <p>${esc(L('تأكيدات:', 'Confirmations:'))} ${esc((s.confirmations || []).map((c) => CONF[c]).filter(Boolean).join(' · ') || '—')}</p>
        <p dir="ltr" class="mono">R:R ${(s.rr || []).map((r) => `1:${num(r, 1)}`).join(' · ')} · ${esc(L('السعر', 'Price'))} ${num(s.price, prec)}${lot?.ok && lot.specSource === 'standard' ? ` · ${esc(L('عقد قياسي', 'standard contract'))}` : ''}</p>
        <p class="muted">${esc(fmtTz(Math.floor(s.createdAt / 1000), getLang()))}${s.status === 'pending' && s.expiresAt ? ` · ${esc(L('بتنتهي', 'expires'))} ${esc(fmtTz(Math.floor(s.expiresAt / 1000), getLang()))}` : ''} · ${esc(L('توصية متابَعة مش صفقة منفذة على حسابك. ثلث عند كل هدف، والوقف للدخول بعد TP1. مش نصيحة مالية.', 'A tracked recommendation, not an execution on your account. One third at each target, stop to entry after TP1. Not financial advice.'))}</p>
      </div>
    </article>`;
  };
  // section header like "ACTIVE SIGNALS (1) · Now at your lots +$31.18 · live every 15 s"
  const section = (title, list) => {
    const tot = list.map(moneyOf).filter(Boolean); const cur = tot[0]?.cur;
    const sum = tot.reduce((t, x) => t + x.now, 0);
    return `<div class="swc-sec"><h2><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3 12h4l3-8 4 16 3-8h4"/></svg>${esc(title)}<i>${list.length}</i></h2>
      <div class="swc-sec-meta">${tot.length ? `<span class="swc-tot">${esc(L('هلّق بلوتاتك', 'Now at your lots'))} <b class="mono ${sum >= 0 ? 'up' : 'down'}" dir="ltr">${money(sum, cur)}</b></span>` : ''}<span class="swc-livetag"><span class="sw-dot on"></span>${esc(L('حيّ · كل 15 ثانية', 'live · every 15 s'))}</span></div>
      <div class="sw-list">${list.map(card).join('')}</div></div>`;
  };
  const empty = (t) => `<p class="sw-empty muted">${esc(t)}</p>`;

  function statsHtml(sum, pol) {
    const tbl = (obj, name) => { const rows = Object.entries(obj || {}); return rows.length ? `<table class="sw-tbl"><thead><tr><th>${esc(name)}</th><th>${esc(L('صفقات', 'Trades'))}</th><th>${esc(L('نسبة الربح', 'Win rate'))}</th><th>${esc(L('نقاط', 'Pips'))}</th><th>R</th></tr></thead><tbody>${rows.map(([k, g]) => `<tr><td dir="ltr">${esc(TF[k] || k)}</td><td>${g.n}</td><td>${Math.round((g.wins / g.n) * 100)}%</td><td class="${g.pips >= 0 ? 'up' : 'down'}" dir="ltr">${signed(g.pips)}</td><td dir="ltr">${signed(g.r, 2)}</td></tr>`).join('')}</tbody></table>` : empty(L('لسا ما في صفقات منتهية.', 'No completed trades yet.')); };
    const tiers = Object.entries(sum.riskTiers || {}).filter(([k]) => TIER[k]);
    return `<div class="sw-grid2">
      <div class="tool-card"><h2 class="card-title">${icons.bars || ''}<span>${esc(L('حسب السوق', 'By instrument'))}</span></h2>${tbl(sum.byMarket, L('السوق', 'Market'))}</div>
      <div class="tool-card"><h2 class="card-title">${icons.clock || icons.alarm || ''}<span>${esc(L('حسب الفريم', 'By timeframe'))}</span></h2>${tbl(sum.byTf, L('الفريم', 'Timeframe'))}</div>
      <div class="tool-card"><h2 class="card-title">${icons.layers || ''}<span>${esc(L('حسب الاستراتيجية', 'By strategy'))}</span></h2>${tbl(Object.fromEntries(Object.entries(sum.byStrategy || {}).map(([k, v]) => [k === 'swing_smc_ict' ? 'SMC/ICT Swing' : k, v])), L('الاستراتيجية', 'Strategy'))}</div>
      <div class="tool-card"><h2 class="card-title">${icons.shield || ''}<span>${esc(L('توزيع المخاطرة', 'Risk allocation'))}</span></h2>
        ${tiers.length ? `<ul class="sw-tiers">${tiers.map(([k, n]) => `<li><span>${esc(TIER[k])}</span><b>${n}</b></li>`).join('')}</ul>` : empty(L('لسا ما في توصيات.', 'No recommendations yet.'))}
        <p class="muted">${esc(L(`متوسط المخاطرة ${sum.avgRiskPct ?? '—'}% · سياسة المخاطرة: من ${pol?.tiers?.at(-1)?.pct ?? 0.3}% لـ ${pol?.safeMax ?? 2}% حسب الثقة، والسقف المطلق ${pol?.hardMax ?? 5}%. المحرك ما بيعطي 25% لحاله أبداً.`, `Average risk ${sum.avgRiskPct ?? '—'}% · policy: ${pol?.tiers?.at(-1)?.pct ?? 0.3}% to ${pol?.safeMax ?? 2}% by confidence, hard ceiling ${pol?.hardMax ?? 5}%. The engine never assigns 25% on its own.`))}</p></div>
    </div>
    <p class="muted sw-note">${esc(L('كل الأرقام من توصيات القناة المسجّلة فعلاً (متابعة على أسعار حقيقية)، بدون أي أرقام مفترضة. النتائج الماضية مش ضمان.', 'Every figure comes from the channel\'s recorded recommendations (tracked on real prices); nothing is assumed. Past results are no guarantee.'))}</p>`;
  }

  function marketsHtml(ms) {
    return `<div class="sw-mk">${ms.map((m) => { const s = MSTATE[m.state] || MSTATE.pending; const inst = getInstrument(m.symbol);
      const last = Object.entries(m.last || {}).map(([tf, x]) => `${TF[tf] || tf}: ${x.state === 'ok' ? '✅' : x.state === 'no_trade' ? L('ما في فرصة', 'no setup') : (MSTATE[x.state]?.[0] || x.state)}${x.confidence != null ? ` (${x.confidence}%)` : ''}`).join(' · ');
      return `<div class="sw-m"><span class="sw-m-ic">${inst?.type === 'forex' ? `<i class="sw-fx" dir="ltr">${esc(m.symbol.slice(0, 3))}</i>` : assetIcon(inst?.icon, 28)}</span><div><b dir="ltr">${esc(m.name)}</b><small class="muted">${esc(last || '—')}</small></div><span class="sw-ms ${s[1]}">${esc(s[0])}</span></div>`; }).join('')}</div>
      <p class="muted sw-note">${esc(L('بيانات حقيقية بس: الكريبتو من Binance، والفوركس والمعادن والمؤشرات من مزوّدي البيانات المربوطين بالموقع. السوق المسكّر أو البيانات المتأخرة ما بيطلع عليها توصيات.', 'Real data only: crypto from Binance; forex, metals and indices from the site\'s connected data providers. A closed market or delayed data never produces a recommendation.'))}</p>`;
  }

  function accountHtml(d) {
    const a = d.account;
    return `<div class="tool-card sw-acc">
      <h2 class="card-title">${icons.wallet || ''}<span>${esc(L('الحساب اللي بنحسب منه اللوت', 'Account used for the lot size'))}</span></h2>
      <p>${a ? esc(a.source === 'mt5' ? L(`ميتاتريدر 5 مربوط: ${a.basis === 'balance' ? 'الرصيد' : 'الإكويتي'} ${num(a.amount, 2)} ${a.currency || ''}`, `MetaTrader 5 linked: ${a.basis} ${num(a.amount, 2)} ${a.currency || ''}`) : L(`رصيد كتبته أنت: ${num(a.amount, 2)} ${a.currency}`, `Balance you entered: ${num(a.amount, 2)} ${a.currency}`)) : esc(L('ما في حساب. اربط ميتاتريدر 5 (الأدق) أو اكتب رصيدك.', 'No account yet. Link MetaTrader 5 (most exact) or enter your balance.'))}</p>
      <form class="sw-form" data-prefs>
        <label>${esc(L('أساس الحساب', 'Risk basis'))}<select class="input" name="basis"><option value="equity">${esc(L('الإكويتي', 'Equity'))}</option><option value="balance">${esc(L('الرصيد', 'Balance'))}</option></select></label>
        <label>${esc(L('رصيد يدوي (بدون ميتاتريدر)', 'Manual balance (without MT5)'))}<input class="input" name="manual" inputmode="decimal" placeholder="10000" dir="ltr"></label>
        <label>${esc(L('العملة', 'Currency'))}<input class="input" name="currency" maxlength="4" placeholder="USD" dir="ltr"></label>
        <button class="btn btn-primary" type="submit">${esc(L('حفظ', 'Save'))}</button>
      </form>
      <p class="muted">${esc(L('مع ميتاتريدر 5 (Expert Advisor نسخة 1.10) اللوت بينحسب من مواصفات وسيطك الحقيقية: قيمة التيك، حجم العقد، أصغر لوت والخطوة. بدونه، الفوركس والذهب والفضة والكريبتو بتنحسب بالعقد القياسي، والمؤشرات ما بتنحسب لأنها بتختلف من وسيط لوسيط.', 'With MetaTrader 5 (Expert Advisor 1.10) the lot uses your broker\'s real specs: tick value, contract size, minimum lot and step. Without it, forex, gold, silver and crypto use the standard contract, and indices are not sized because they differ by broker.'))} <a href="#/app/mt5">${esc(L('ربط ميتاتريدر 5', 'Link MetaTrader 5'))}</a></p>
    </div>`;
  }

  function paint() {
    if (locked) { el.querySelector('[data-panel]').innerHTML = `<div class="tool-card sw-lock"><h2>${esc(L('Swing Pulse Pro مش ضمن باقتك', 'Swing Pulse Pro is not in your plan'))}</h2><p class="muted">${esc(locked === 'platform_plan_required' ? L('اشتراك القناة لحاله ما بيشمل هالقناة. رقّي لباقة المنصة.', 'A channel-only subscription does not include this channel. Upgrade to a platform plan.') : L('هالقناة بدها باقة مدفوعة فعّالة.', 'This channel needs an active paid plan.'))}</p><a class="btn btn-primary" href="#/app/pricing">${esc(L('شوف الباقات', 'See plans'))}</a></div>`; return; }
    const d = D || { signals: [], markets: [], summary: {} }; const sum = d.summary || {};
    const sigs = d.signals || [];
    const open = sigs.filter((s) => ['active', 'tp1', 'tp2'].includes(s.status)); const pend = sigs.filter((s) => s.status === 'pending'); const done = sigs.filter((s) => !LIVE.includes(s.status));
    el.querySelector('[data-live]').innerHTML = d.configured === false ? `<span class="sw-dot off"></span>${esc(L('المحرك مش شغّال على السيرفر هلّق', 'The engine is not running on the server right now'))}`
      : `<span class="sw-dot ${d.lastTrack && Date.now() - d.lastTrack < 120_000 ? 'on' : 'off'}"></span>${esc(L('تحديث كل 15 ثانية', 'Updates every 15 s'))}${d.lastTrack ? ` · ${esc(fmtTz(Math.floor(d.lastTrack / 1000), getLang()))}` : ''}`;
    const kp = [
      [L('مفتوحة', 'Active'), open.length], [L('معلّقة', 'Pending'), pend.length], [L('منتهية', 'Completed'), sum.completed ?? 0],
      [L('ربح / خسارة', 'Wins / losses'), `${sum.wins ?? 0} / ${sum.losses ?? 0}`], [L('نسبة النجاح', 'Win rate'), sum.winRate == null ? '—' : `${Math.round(sum.winRate * 100)}%`],
      [L('نقاط محققة', 'Realized pips'), signed(sum.realizedPips ?? 0)], [L('متوسط العائد/المخاطرة', 'Avg R:R'), sum.avgPlannedRR == null ? '—' : `1:${sum.avgPlannedRR}`],
    ];
    el.querySelector('[data-kpis]').innerHTML = kp.map(([k, v]) => `<div class="sw-kpi"><span>${esc(k)}</span><b dir="ltr">${esc(String(v))}</b></div>`).join('');
    el.querySelector('[data-n="open"]').textContent = open.length || ''; el.querySelector('[data-n="pending"]').textContent = pend.length || ''; el.querySelector('[data-n="done"]').textContent = done.length || '';
    const P = el.querySelector('[data-panel]');
    if (tab === 'open') P.innerHTML = open.length ? section(L('توصيات فعّالة', 'ACTIVE SIGNALS'), open) : empty(L('ما في توصيات مفتوحة هلّق. المحرك بيبعت بس لما الإعداد قوي كفاية.', 'No open recommendations now. The engine only sends one when the setup is strong enough.'));
    else if (tab === 'pending') P.innerHTML = pend.length ? section(L('أوامر معلّقة', 'PENDING SIGNALS'), pend) : empty(L('ما في أوامر ليميت معلّقة.', 'No pending limit orders.'));
    else if (tab === 'done') P.innerHTML = done.length ? section(L('توصيات منتهية', 'COMPLETED SIGNALS'), done.slice(0, 60)) : empty(L('لسا ما في توصيات منتهية.', 'No completed recommendations yet.'));
    else if (tab === 'stats') P.innerHTML = statsHtml(sum, d.policy);
    else if (tab === 'markets') P.innerHTML = marketsHtml(d.markets || []);
    else if (tab === 'account') { P.innerHTML = accountHtml(d); loadPrefs(); }
    P.querySelectorAll('.swc').forEach((c) => { if (openWhy.has(c.dataset.id)) { const w = c.querySelector('.swc-why'); if (w) { w.hidden = false; c.querySelector('[data-why]')?.classList.add('on'); } } });
    const q = d.access?.quota; el.querySelector('[data-foot]').textContent = `${L('التوقيت', 'Time zone')}: ${tzLabel()}${q != null ? ` · ${L('توصيات باقتك هالشهر', 'Your plan this month')}: ${d.access.used}/${q}` : ''} · ${L('تحليل للتعليم، مش نصيحة مالية. التداول فيه مخاطرة.', 'Analysis for education, not financial advice. Trading involves risk.')}`;
  }

  async function loadPrefs() {
    const f = el.querySelector('[data-prefs]'); if (!f) return;
    try { const p = await apiRequest('GET', '/api/swing/prefs', undefined, 10000); f.basis.value = p.basis || 'equity'; if (p.manual) f.manual.value = p.manual; if (p.currency) f.currency.value = p.currency; } catch { /* keeps the empty form */ }
    f.addEventListener('submit', async (e) => {
      e.preventDefault();
      const manual = f.manual.value.trim() ? Number(f.manual.value.replace(',', '.')) : null;
      try { await apiRequest('PUT', '/api/swing/prefs', { basis: f.basis.value, manual: manual ?? 0, currency: f.currency.value.trim().toUpperCase() || null }, 10000); toast(L('انحفظ', 'Saved'), 'success'); load(); }
      catch { toast(L('تأكد من الرصيد والعملة (مثلاً USD).', 'Check the balance and the currency (e.g. USD).'), 'error'); }
    }, { once: true });
  }

  el.querySelector('[data-panel]').addEventListener('click', (e) => {   // the document icon opens the analysis details
    const b = e.target.closest('[data-why]'); if (!b) return;
    const w = b.closest('.swc')?.querySelector('.swc-why'); if (!w) return; w.hidden = !w.hidden; b.classList.toggle('on', !w.hidden);
    if (!w.hidden) openWhy.add(b.closest('.swc').dataset.id); else openWhy.delete(b.closest('.swc').dataset.id);
  });
  el.querySelector('[data-tabs]').addEventListener('click', (e) => {
    const b = e.target.closest('[data-tab]'); if (!b) return;
    tab = b.dataset.tab; el.querySelectorAll('[data-tab]').forEach((x) => x.setAttribute('aria-selected', String(x === b))); paint();
  });

  const load = async () => {
    if (stop) return;
    try { D = await apiRequest('GET', '/api/swing/feed', undefined, 15000); locked = null; }
    catch (e) { if (['plan_upgrade_required', 'platform_plan_required'].includes(e.code)) locked = e.code; else if (!D) D = { configured: false, signals: [], markets: [], summary: {} }; }
    // the account form is not repainted under the person's fingers
    if (!(tab === 'account' && el.querySelector('[data-prefs]') && el.contains(document.activeElement) && document.activeElement.closest('[data-prefs]'))) paint();
    if (!stop) timer = setTimeout(load, POLL_MS);
  };
  paint(); load();
  el._cleanup = () => { stop = true; clearTimeout(timer); };
  return el;
}
