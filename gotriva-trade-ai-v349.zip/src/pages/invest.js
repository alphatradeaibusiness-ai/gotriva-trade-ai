// v347 Investment section — watch-list of the world's biggest companies with live prices, an interactive chart, momentum
// indicators, the AI news sentiment, the company's reported fundamentals, and the AI "ready trade" (BUY / SELL / WAIT with entry,
// stop, targets, exit rule, confidence and the evidence behind it). Everything comes from /api/invest/* (real data only).
import { h, esc } from '../utils/dom.js';
import { getLang } from '../i18n/index.js';
import { apiRequest } from '../services/ai/gateway.js';
import { ema } from '../indicators/index.js';
import { createChart, CandlestickSeries, LineSeries, HistogramSeries } from 'lightweight-charts';
import '../styles/invest.css';

const QUOTE_MS = 15_000; const ANALYSIS_MS = 5 * 60_000;

export function renderInvest() {
  const AR = getLang() === 'ar'; const L = (ar, en) => (AR ? ar : en);
  const n2 = (v, d = 2) => (Number.isFinite(v) ? Number(v).toLocaleString('en-US', { minimumFractionDigits: d, maximumFractionDigits: d }) : '—');
  const pct = (v, d = 2) => (Number.isFinite(v) ? `${v > 0 ? '+' : ''}${Number(v).toFixed(d)}%` : '—');
  const big = (v) => (!Number.isFinite(v) ? '—' : v >= 1e12 ? `$${(v / 1e12).toFixed(2)}T` : v >= 1e9 ? `$${(v / 1e9).toFixed(1)}B` : `$${(v / 1e6).toFixed(0)}M`);
  const ago = (t) => { if (!t) return '—'; const m = Math.round((Date.now() - t) / 60000); return m < 1 ? L('هلّق', 'now') : m < 60 ? L(`قبل ${m} د`, `${m}m ago`) : m < 1440 ? L(`قبل ${Math.round(m / 60)} س`, `${Math.round(m / 60)}h ago`) : L(`قبل ${Math.round(m / 1440)} يوم`, `${Math.round(m / 1440)}d ago`); };
  const SRC = { twelvedata: 'Twelve Data', finnhub: 'Finnhub' };

  const el = h(`<section class="subpage invest page-enter" dir="${AR ? 'rtl' : 'ltr'}">
    <header class="iv-hero">
      <div><h1>${esc(L('الاستثمار', 'Investing'))} <span class="iv-tag">AI</span></h1>
      <p class="muted">${esc(L('أقوى الشركات العالمية: أسعار حيّة، شارت تفاعلي، مؤشرات الزخم، تحليل مشاعر الأخبار بالذكاء الاصطناعي مع البيانات المالية، وصفقة جاهزة موثّقة لكل شركة.', 'The world\'s biggest companies: live prices, an interactive chart, momentum, AI news sentiment with the financials, and a documented ready trade for each company.'))}</p></div>
      <div class="iv-status" data-status></div>
    </header>
    <div class="iv-grid">
      <aside class="iv-watch" aria-label="${esc(L('قائمة المراقبة', 'Watch-list'))}"><h2>${esc(L('قائمة المراقبة', 'Watch-list'))}</h2><div class="iv-list" data-list><p class="muted iv-load">${esc(L('عم نجيب الأسعار…', 'Loading prices…'))}</p></div></aside>
      <div class="iv-main">
        <div class="iv-card iv-head" data-head></div>
        <div class="iv-card iv-chartcard">
          <div class="iv-tfs" role="tablist"><button type="button" data-tf="1day" aria-selected="true">${esc(L('يومي', 'Daily'))}</button><button type="button" data-tf="1h" aria-selected="false">${esc(L('ساعة', 'Hourly'))}</button><span class="iv-legend"><i class="e20"></i>EMA 20 <i class="e50"></i>EMA 50 <i class="e200"></i>EMA 200</span></div>
          <div class="iv-chart" data-chart></div>
        </div>
        <div class="iv-mom" data-mom></div>
        <div class="iv-two">
          <div class="iv-card iv-trade" data-trade></div>
          <div class="iv-card iv-senti" data-senti></div>
        </div>
        <div class="iv-card iv-fund" data-fund></div>
      </div>
    </div>
    <p class="muted iv-foot">${esc(L('تحليل آلي للتعليم، مش نصيحة مالية. الأسهم ممكن تنزل وتطلع بقوة، وقرار الشراء أو البيع إلك. الأسعار من مزوّد البيانات وممكن تكون متأخرة دقائق حسب الباقة.', 'Automated analysis for education, not financial advice. Stocks can move sharply; the decision is yours. Prices come from the data provider and can be delayed by minutes depending on the plan.'))}</p>
  </section>`);

  let W = []; let Q = {}; let sel = 'AAPL'; let tf = '1day'; let stop = false; let tq = 0; let ta = 0; let A = null; let chart = null; let series = null;
  const nameOf = (s) => { const w = W.find((x) => x.s === s); return w ? (AR ? w.n.ar : w.n.en) : s; };
  const spark = {};   // symbol → closes (daily) for the small line

  function sparkSvg(c, up) {
    if (!c || c.length < 5) return '';
    const v = c.slice(-60); const mn = Math.min(...v); const mx = Math.max(...v); const k = mx - mn || 1;
    const pts = v.map((x, i) => `${((i / (v.length - 1)) * 100).toFixed(1)},${(28 - ((x - mn) / k) * 26).toFixed(1)}`).join(' ');
    return `<svg class="iv-spark ${up ? 'up' : 'down'}" viewBox="0 0 100 30" preserveAspectRatio="none" aria-hidden="true"><polyline points="${pts}"/></svg>`;
  }
  function paintList() {
    const box = el.querySelector('[data-list]');
    if (!W.length) return;
    box.innerHTML = W.map((w) => { const q = Q[w.s]; const up = (q?.changePct ?? 0) >= 0;
      return `<button type="button" class="iv-row ${w.s === sel ? 'on' : ''}" data-s="${w.s}"><span class="iv-logo" data-l="${w.s[0]}">${esc(w.s.slice(0, 2))}</span>
        <span class="iv-nm"><b>${esc(AR ? w.n.ar : w.n.en)}</b><small dir="ltr">${esc(w.s)}</small></span>${sparkSvg(spark[w.s], up)}
        <span class="iv-px"><b class="mono" dir="ltr">${q ? `$${n2(q.price)}` : '—'}</b><small class="mono ${up ? 'up' : 'down'}" dir="ltr">${q ? pct(q.changePct) : ''}</small></span></button>`; }).join('');
  }
  function paintStatus(st, qs) {
    el.querySelector('[data-status]').innerHTML = [
      `<span class="iv-pill ${st?.marketOpen ? 'ok' : ''}"><i></i>${esc(st?.marketOpen ? L('السوق الأمريكي مفتوح', 'US market open') : L('السوق الأمريكي مسكّر', 'US market closed'))}</span>`,
      `<span class="iv-pill">${esc(L('الأسعار', 'Prices'))}: ${esc(SRC[qs?.source] || L('غير متاحة', 'unavailable'))}${qs?.at ? ` · ${esc(ago(qs.at))}` : ''}</span>`,
      `<span class="iv-pill ${st?.ai ? 'ok' : 'warn'}">${esc(st?.ai ? L('محرك AI شغّال', 'AI engine on') : L('AI مش مربوط', 'AI not connected'))}</span>`,
    ].join('');
  }
  async function loadQuotes() {
    if (stop) return;
    try {
      const r = await apiRequest('GET', '/api/invest/watch', undefined, 20000);
      W = r.watch || W; for (const q of r.quotes?.items || []) Q[q.symbol] = q;
      paintStatus(r.status, r.quotes); paintList(); paintHead();
      if (!r.quotes) el.querySelector('[data-list]').insertAdjacentHTML('afterbegin', `<p class="iv-warn">${esc(L('مزوّد الأسعار ما ردّ هلّق. بنرجع نحاول.', 'The price provider did not answer. Retrying.'))}</p>`);
    } catch (e) {
      if (['plan_upgrade_required', 'platform_plan_required'].includes(e.code)) { lockPage(); return; }
      el.querySelector('[data-list]').innerHTML = `<p class="iv-warn">${esc(L('ما قدرنا نجيب الأسعار.', 'Could not load prices.'))}</p>`;
    }
    if (!stop) tq = setTimeout(loadQuotes, QUOTE_MS);
  }
  function lockPage() {
    stop = true;
    el.querySelector('.iv-grid').innerHTML = `<div class="iv-card iv-lock"><h2>${esc(L('قسم الاستثمار مش ضمن باقتك', 'Investing is not in your plan'))}</h2><p class="muted">${esc(L('بدها باقة منصة مدفوعة فعّالة.', 'It needs an active paid platform plan.'))}</p><a class="btn btn-primary" href="#/app/pricing">${esc(L('شوف الباقات', 'See plans'))}</a></div>`;
  }

  function paintHead() {
    const q = Q[sel]; const up = (q?.changePct ?? 0) >= 0;
    el.querySelector('[data-head]').innerHTML = `<span class="iv-logo lg" data-l="${sel[0]}">${esc(sel.slice(0, 2))}</span>
      <div class="iv-hn"><h2>${esc(nameOf(sel))} <small dir="ltr">${esc(sel)}</small></h2><small class="muted">${q?.at ? `${esc(L('آخر سعر', 'Last price'))} ${esc(ago(q.at))}` : ''}</small></div>
      <div class="iv-hp"><b class="mono" dir="ltr">${q ? `$${n2(q.price)}` : '—'}</b><span class="mono ${up ? 'up' : 'down'}" dir="ltr">${q ? `${q.change > 0 ? '+' : ''}${n2(q.change)} (${pct(q.changePct)})` : ''}</span></div>
      <dl class="iv-hstats" dir="ltr"><div><dt>${esc(L('أعلى اليوم', 'High'))}</dt><dd>${n2(q?.high)}</dd></div><div><dt>${esc(L('أدنى اليوم', 'Low'))}</dt><dd>${n2(q?.low)}</dd></div><div><dt>${esc(L('إغلاق أمس', 'Prev close'))}</dt><dd>${n2(q?.prevClose)}</dd></div><div><dt>${esc(L('مدى 52 أسبوع', '52-wk range'))}</dt><dd>${q?.lo52 ? `${n2(q.lo52, 0)}–${n2(q.hi52, 0)}` : (A?.trade?.tech ? `${n2(A.trade.tech.ind.lo52, 0)}–${n2(A.trade.tech.ind.hi52, 0)}` : '—')}</dd></div></dl>`;
  }

  // ── chart ──
  function ensureChart() {
    if (chart) return;
    const box = el.querySelector('[data-chart]');
    chart = createChart(box, { autoSize: true, layout: { background: { type: 'solid', color: 'transparent' }, textColor: '#9aa3c7', fontSize: 11, attributionLogo: true },
      grid: { vertLines: { color: 'rgba(148,130,255,.05)' }, horzLines: { color: 'rgba(148,130,255,.05)' } }, rightPriceScale: { borderColor: 'rgba(148,130,255,.14)' },
      timeScale: { borderColor: 'rgba(148,130,255,.14)', timeVisible: true, secondsVisible: false }, localization: { locale: 'en-US' },
      crosshair: { vertLine: { color: 'rgba(167,139,250,.5)', labelBackgroundColor: '#5b21b6' }, horzLine: { color: 'rgba(167,139,250,.5)', labelBackgroundColor: '#5b21b6' } } });
    series = {
      c: chart.addSeries(CandlestickSeries, { upColor: '#22c55e', downColor: '#f0444f', borderVisible: false, wickUpColor: '#22c55e', wickDownColor: '#f0444f' }),
      v: chart.addSeries(HistogramSeries, { priceScaleId: 'vol', priceFormat: { type: 'volume' }, color: 'rgba(124,140,255,.25)' }),
      e20: chart.addSeries(LineSeries, { color: '#38bdf8', lineWidth: 1, priceLineVisible: false, lastValueVisible: false }),
      e50: chart.addSeries(LineSeries, { color: '#f5c451', lineWidth: 1, priceLineVisible: false, lastValueVisible: false }),
      e200: chart.addSeries(LineSeries, { color: '#c084fc', lineWidth: 1, priceLineVisible: false, lastValueVisible: false }),
    };
    chart.priceScale('vol').applyOptions({ scaleMargins: { top: 0.82, bottom: 0 } });
  }
  async function loadChart() {
    ensureChart();
    const box = el.querySelector('[data-chart]'); box.dataset.state = 'loading';
    try {
      const r = await apiRequest('GET', `/api/invest/candles?s=${sel}&tf=${tf}`, undefined, 20000);
      const cs = r.candles || []; const closes = cs.map((c) => c.close);
      series.c.setData(cs.map((c) => ({ time: c.time, open: c.open, high: c.high, low: c.low, close: c.close })));
      series.v.setData(cs.map((c) => ({ time: c.time, value: c.volume || 0, color: c.close >= c.open ? 'rgba(34,197,94,.3)' : 'rgba(240,68,79,.3)' })));
      for (const [k, p] of [['e20', 20], ['e50', 50], ['e200', 200]]) { const e = ema(closes, p); series[k].setData(cs.map((c, i) => (e[i] != null ? { time: c.time, value: e[i] } : { time: c.time }))); }
      chart.timeScale().fitContent();
      if (tf === '1day') spark[sel] = closes;
      box.dataset.state = '';
    } catch { box.dataset.state = 'error'; }
  }
  async function loadSparks() {   // small lines in the list (daily candles are cached for hours on the server)
    for (const w of W) { if (stop || spark[w.s]) continue; try { const r = await apiRequest('GET', `/api/invest/candles?s=${w.s}&tf=1day`, undefined, 20000); spark[w.s] = (r.candles || []).map((c) => c.close); paintList(); } catch { /* the row just has no line */ } }
  }

  // ── analysis ──
  const ACT = { buy: [L('شراء', 'BUY'), 'buy'], sell: [L('بيع / خروج', 'SELL / EXIT'), 'sell'], wait: [L('انتظار', 'WAIT'), 'wait'] };
  const PART = { tech: L('التحليل الفني والزخم', 'Technicals & momentum'), news: L('مشاعر الأخبار (AI)', 'News sentiment (AI)'), fund: L('البيانات المالية', 'Financials') };
  const CHK = { above_ema50: L('السعر فوق/تحت EMA 50', 'Price vs EMA 50'), above_ema200: L('السعر فوق/تحت EMA 200', 'Price vs EMA 200'), ema20_50: 'EMA 20 / EMA 50', rsi: 'RSI 14', macd_hist: 'MACD', roc20: L('زخم 20 يوم', '20-day momentum') };
  const FN = { revenue_growth: L('نمو الإيرادات', 'Revenue growth'), eps_growth: L('نمو الأرباح للسهم', 'EPS growth'), net_margin: L('هامش الربح الصافي', 'Net margin'), pe: L('مكرر الربحية P/E', 'P/E'), debt_equity: L('الدين إلى حقوق الملكية', 'Debt / equity') };
  function paintMom() {
    const t = A?.trade?.tech; const box = el.querySelector('[data-mom]');
    if (!t) { box.innerHTML = `<div class="iv-card"><p class="muted">${esc(L('ما في شموع كافية للتحليل هلّق.', 'Not enough candles to analyse right now.'))}</p></div>`; return; }
    const i = t.ind; const rs = i.rsi ?? 50;
    box.innerHTML = [
      `<div class="iv-m"><span>RSI 14</span><b class="mono">${n2(i.rsi, 1)}</b><i class="iv-bar"><em style="width:${Math.max(0, Math.min(100, rs))}%" class="${rs > 70 ? 'hot' : rs < 30 ? 'cold' : ''}"></em></i><small>${esc(rs > 70 ? L('تشبّع شرائي', 'Overbought') : rs < 30 ? L('تشبّع بيعي', 'Oversold') : rs >= 55 ? L('زخم صاعد', 'Bullish momentum') : rs <= 45 ? L('زخم هابط', 'Bearish momentum') : L('محايد', 'Neutral'))}</small></div>`,
      `<div class="iv-m"><span>MACD</span><b class="mono ${i.macdHist >= 0 ? 'up' : 'down'}" dir="ltr">${i.macdHist > 0 ? '+' : ''}${n2(i.macdHist, 2)}</b><small>${esc(i.macdHist >= 0 ? L('فوق خط الإشارة', 'Above signal') : L('تحت خط الإشارة', 'Below signal'))}</small></div>`,
      `<div class="iv-m"><span>${esc(L('الاتجاه (EMA)', 'Trend (EMA)'))}</span><b>${esc(i.price > i.ema50 && (i.ema200 == null || i.price > i.ema200) ? L('صاعد', 'Up') : i.price < i.ema50 && (i.ema200 == null || i.price < i.ema200) ? L('هابط', 'Down') : L('متذبذب', 'Mixed'))}</b><small dir="ltr">50: ${n2(i.ema50)} · 200: ${n2(i.ema200)}</small></div>`,
      `<div class="iv-m"><span>${esc(L('زخم 20 / 60 يوم', '20 / 60-day momentum'))}</span><b class="mono ${i.roc20 >= 0 ? 'up' : 'down'}" dir="ltr">${pct(i.roc20, 1)}</b><small dir="ltr">60d ${pct(i.roc60, 1)}</small></div>`,
      `<div class="iv-m"><span>${esc(L('بعد عن قمة 52 أسبوع', 'From 52-wk high'))}</span><b class="mono" dir="ltr">${pct(i.fromHighPct, 1)}</b><small dir="ltr">ATR ${n2(i.atr)}</small></div>`,
    ].join('');
  }
  function paintTrade() {
    const t = A?.trade; const box = el.querySelector('[data-trade]');
    if (!t) { box.innerHTML = `<p class="muted">${esc(L('عم نحلّل…', 'Analysing…'))}</p>`; return; }
    const act = ACT[t.action] || ACT.wait; const long = t.action === 'buy';
    const lv = (lab, v, cls = '') => `<div class="iv-lv ${cls}"><dt>${lab}</dt><dd class="mono">$${n2(v)}</dd>${Number.isFinite(v) && Number.isFinite(t.entry) && lab !== 'ENTRY' ? `<small class="mono">${pct(((v - t.entry) / t.entry) * 100, 1)}</small>` : ''}</div>`;
    const parts = Object.entries(t.parts || {}).map(([k, p]) => `<li class="${p ? '' : 'na'}"><span>${esc(PART[k])}</span>${p ? `<i class="iv-sbar"><em style="--v:${p.score}"></em></i><b class="mono ${p.score >= 0 ? 'up' : 'down'}" dir="ltr">${p.score > 0 ? '+' : ''}${n2(p.score, 2)}</b><small>${Math.round((p.weight || 0) * 100)}%</small>` : `<small>${esc(k === 'news' ? (A?.sources?.ai ? L('ما في أخبار حديثة', 'no recent news') : L('AI مش مربوط', 'AI not connected')) : k === 'fund' ? L('غير متاحة بباقة البيانات', 'not in the data plan') : L('ما في بيانات', 'no data'))}</small>`}</li>`).join('');
    const evid = [];
    for (const c of t.tech?.checks || []) evid.push(`<li><span>${esc(CHK[c.id] || c.id)}</span><b class="${c.w > 0 ? 'up' : c.w < 0 ? 'down' : ''}" dir="ltr">${c.w > 0 ? '▲' : c.w < 0 ? '▼' : '•'} ${c.v ?? ''}</b></li>`);
    for (const f of t.fund?.notes || []) evid.push(`<li><span>${esc(FN[f.id] || f.id)}</span><b class="${f.w > 0 ? 'up' : f.w < 0 ? 'down' : ''}" dir="ltr">${f.w > 0 ? '▲' : f.w < 0 ? '▼' : '•'} ${f.id === 'pe' || f.id === 'debt_equity' ? n2(f.v, 1) : `${n2(f.v, 1)}%`}</b></li>`);
    box.innerHTML = `<div class="iv-t-top"><h3>${esc(L('صفقة جاهزة', 'Ready trade'))}</h3><span class="iv-act ${act[1]}" dir="ltr">${esc(act[0])}${t.action !== 'wait' ? ` · ${t.entryType === 'limit' ? 'LIMIT' : 'MARKET'}` : ''}</span>
        <div class="iv-ring" style="--v:${t.confidence}"><svg viewBox="0 0 36 36" aria-hidden="true"><circle cx="18" cy="18" r="15.5"/><circle class="arc" cx="18" cy="18" r="15.5" pathLength="100"/></svg><b>${t.confidence}%</b><small>${esc(L('ثقة', 'conf.'))}</small></div></div>
      ${t.action === 'wait' ? `<p class="iv-wait">${esc(t.reason === 'no_chart_data' ? L('ما في بيانات أسعار كافية لصفقة.', 'Not enough price data for a trade.') : L('الإشارات متعارضة أو ضعيفة: المحرك ما بيعطي صفقة هلّق. استنّى تأكيد أوضح.', 'Signals are mixed or weak: no trade now. Wait for clearer confirmation.'))}</p>`
      : `<dl class="iv-lvs" dir="ltr">${lv('ENTRY', t.entry)}${lv('STOP', t.stop, 'sl')}${lv('TARGET 1', t.targets[0], 'tp')}${lv('TARGET 2', t.targets[1], 'tp')}</dl>
         <p class="iv-rule">${esc(L(`المدى: أسابيع. ${t.entryType === 'limit' ? 'السعر بعيد عن متوسط 20 يوم، فالدخول ليميت عند المتوسط بدل اللحاق بالسعر. ' : ''}الخروج: ${long ? 'إغلاق يومي تحت EMA 50' : 'إغلاق يومي فوق EMA 50'} أو ضرب الوقف. العائد للمخاطرة 1:${n2(t.rr?.[0], 1)} و 1:${n2(t.rr?.[1], 1)}.`, `Horizon: weeks. ${t.entryType === 'limit' ? 'Price is stretched from its 20-day average, so a limit at the average instead of chasing. ' : ''}Exit: ${long ? 'a daily close below EMA 50' : 'a daily close above EMA 50'} or the stop. Reward/risk 1:${n2(t.rr?.[0], 1)} and 1:${n2(t.rr?.[1], 1)}.`))}</p>`}
      <ul class="iv-parts">${parts}</ul>
      <details class="iv-ev"><summary>${esc(L('الأدلة والمصادر (التوثيق)', 'Evidence & sources'))}</summary><ul>${evid.join('')}</ul>
        <p class="muted">${esc(L('المصادر', 'Sources'))}: ${esc([A.sources?.prices && `${L('الأسعار', 'prices')} ${SRC[A.sources.prices]}`, A.sources?.candles && `${L('الشموع', 'candles')} ${SRC[A.sources.candles]}`, A.sentiment && `${L('الأخبار', 'news')} ${SRC[A.sources.news]} + AI`, A.fundamentals?.source && `${L('المالية', 'financials')} ${SRC[A.fundamentals.source]}`].filter(Boolean).join(' · '))} · ${esc(L('وقت التحليل', 'analysed'))} ${esc(ago(A.at))}</p></details>`;
  }
  function paintSenti() {
    const s = A?.sentiment; const nw = A?.news || []; const box = el.querySelector('[data-senti]');
    const score = s?.score ?? null;
    box.innerHTML = `<div class="iv-s-top"><h3>${esc(L('مشاعر الأخبار (AI)', 'News sentiment (AI)'))}</h3>${score != null ? `<span class="iv-sg ${s.label}" dir="ltr">${score > 0 ? '+' : ''}${n2(score, 2)} · ${esc(s.label === 'positive' ? L('إيجابية', 'Positive') : s.label === 'negative' ? L('سلبية', 'Negative') : L('محايدة', 'Neutral'))}</span>` : ''}</div>
      ${score != null ? `<div class="iv-gauge"><i style="--v:${score}"></i></div>${s.summary ? `<p class="iv-sum">${esc(s.summary)}</p>` : ''}` : `<p class="muted">${esc(!A?.sources?.ai ? L('محرك AI مش مربوط، فما في تحليل مشاعر.', 'The AI engine is not connected, so there is no sentiment.') : nw.length ? L('ما قدرنا نحلل الأخبار هلّق.', 'Could not analyse the news right now.') : L('ما في أخبار حديثة لهالشركة.', 'No recent news for this company.'))}</p>`}
      <ul class="iv-news">${nw.map((x, i) => { const it = s?.items?.find((y) => y.i === i); const v = it?.s;
        return `<li><i class="iv-nd ${v == null ? '' : v > 0.15 ? 'pos' : v < -0.15 ? 'neg' : 'neu'}" title="${v == null ? '' : n2(v, 2)}"></i><div>${x.url ? `<a href="${esc(x.url)}" target="_blank" rel="noopener noreferrer" dir="auto">${esc(x.title)}</a>` : `<b dir="auto">${esc(x.title)}</b>`}<small class="muted">${esc(x.source || '')} · ${esc(ago(x.at))}${it?.why ? ` · ${esc(it.why)}` : ''}</small></div></li>`; }).join('') || ''}</ul>`;
  }
  function paintFund() {
    const f = A?.fundamentals; const box = el.querySelector('[data-fund]');
    if (!f || f.unavailable) { box.innerHTML = `<h3>${esc(L('البيانات المالية', 'Financials'))}</h3><p class="muted">${esc(L('البيانات المالية بدها FINNHUB_API_KEY على السيرفر، أو باقة Pro من Twelve Data. التحليل بيكمل بالفني والأخبار، وبيقول هيك بالصفقة.', 'Financials need FINNHUB_API_KEY on the server, or a Twelve Data Pro plan. The analysis continues with technicals and news, and says so in the trade.'))}</p>`; return; }
    const cell = (k, v) => `<div><dt>${esc(k)}</dt><dd class="mono" dir="ltr">${v}</dd></div>`;
    box.innerHTML = `<h3>${esc(L('البيانات المالية', 'Financials'))} <small class="muted">${esc(SRC[f.source] || '')}</small></h3><dl class="iv-fgrid">
      ${cell(L('القيمة السوقية', 'Market cap'), big(f.marketCap))}${cell('P/E', n2(f.pe, 1))}${cell(L('P/E المتوقع', 'Forward P/E'), n2(f.forwardPe, 1))}
      ${cell(L('نمو الإيرادات', 'Revenue growth'), Number.isFinite(f.revenueGrowth) ? pct(f.revenueGrowth * 100, 1) : '—')}${cell(L('نمو أرباح السهم', 'EPS growth'), Number.isFinite(f.epsGrowth) ? pct(f.epsGrowth * 100, 1) : '—')}
      ${cell(L('هامش الربح', 'Net margin'), Number.isFinite(f.netMargin) ? `${n2(f.netMargin * 100, 1)}%` : '—')}${cell(L('الدين/الملكية', 'Debt/equity'), n2(f.debtToEquity, 2))}${cell('Beta', n2(f.beta, 2))}</dl>`;
  }
  async function loadAnalysis() {
    if (stop) return; clearTimeout(ta);
    const want = sel; A = null; paintTrade();
    el.querySelector('[data-senti]').innerHTML = `<p class="muted">${esc(L('الذكاء الاصطناعي عم يقرأ الأخبار…', 'The AI is reading the news…'))}</p>`;
    try { const r = await apiRequest('GET', `/api/invest/analysis?s=${want}&lang=${AR ? 'ar' : 'en'}`, undefined, 60000); if (want !== sel) return; A = r; if (r.quote) Q[want] = { ...Q[want], ...r.quote }; }
    catch (e) { if (want !== sel) return; if (['plan_upgrade_required', 'platform_plan_required'].includes(e.code)) { lockPage(); return; } A = null; el.querySelector('[data-trade]').innerHTML = `<p class="iv-warn">${esc(L('التحليل مش متاح هلّق.', 'Analysis is unavailable right now.'))}</p>`; return; }
    paintHead(); paintMom(); paintTrade(); paintSenti(); paintFund();
    if (!stop) ta = setTimeout(loadAnalysis, ANALYSIS_MS);
  }

  el.querySelector('[data-list]').addEventListener('click', (e) => { const b = e.target.closest('[data-s]'); if (!b || b.dataset.s === sel) return; sel = b.dataset.s; paintList(); paintHead(); loadChart(); loadAnalysis(); });
  el.querySelector('.iv-tfs').addEventListener('click', (e) => { const b = e.target.closest('[data-tf]'); if (!b) return; tf = b.dataset.tf; el.querySelectorAll('[data-tf]').forEach((x) => x.setAttribute('aria-selected', String(x === b))); loadChart(); });

  setTimeout(() => { if (stop) return; loadQuotes().then(() => loadSparks()); loadChart(); loadAnalysis(); }, 0);
  el._cleanup = () => { stop = true; clearTimeout(tq); clearTimeout(ta); try { chart?.remove(); } catch { /* */ } };
  return el;
}
