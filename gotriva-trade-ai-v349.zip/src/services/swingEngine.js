// Swing Pulse Pro (v346) — the swing engine of an INDEPENDENT recommendation channel. Pure functions (no DOM, no network):
// every number comes from the candles, the live quote and the calendar passed in, so every rule is tested in node.
//
// Independence: this channel has its own engine, scanner, state file, feed, tracking, notifications and page. It never writes
// to, reads the state of, or changes the main channel, «توصية AI», Gotriva Elite Signals, NOVA PULSE or EDH. It only USES the
// shared, read-only SMC / ICT reader (smcAssist.analyzeSmcIct) and the plain indicator maths (indicators/index.js).
//
// Timeframes: H1, H4 and Daily only. Nothing is ever published from a lower timeframe.
// Analysis = SMC / ICT (structure BOS/CHoCH, liquidity sweep, OB, FVG, breaker, premium/discount, OTE, higher-timeframe bias)
//          + technical confirmation (EMA 20/50/100/200, RSI, MACD, volume, support/resistance, momentum, volatility).
// Not every indicator has to agree: they add to (or take from) one confidence score; only a setup above the quality threshold
// becomes a recommendation.
//
// Risk: the AI chooses a risk % PER RECOMMENDATION from that confidence and the market conditions (volatility, stop quality,
// news, the channel's own measured results, open exposure). Platform limits are hard limits: the normal policy tops out at
// SAFE_MAX %, a configured ceiling can never pass HARD_MAX % — a 25 % allocation is never assigned automatically.
import { analyzeSmcIct } from './smcAssist.js';
import { ema, rsi, atr } from '../indicators/index.js';
import { newsRisk } from './synthesis.js';

export const SWING_BRAND = 'Swing Pulse Pro';
export const SWING_ENGINE_VERSION = 'swing-1.0 (v346)';
export const SWING_STRATEGY = 'swing_smc_ict';
export const SWING_TFS = ['1h', '4h', '1D'];
export const TF_SEC = { '1h': 3600, '4h': 14400, '1D': 86400 };
export const LIVE_STATUSES = ['pending', 'active', 'tp1', 'tp2'];
export const FINAL_STATUSES = ['tp3', 'sl', 'closed', 'cancelled'];
export const STATUSES = [...LIVE_STATUSES, ...FINAL_STATUSES];

// Quality threshold and risk policy (percent of the account per trade).
export const MIN_CONFIDENCE = 62;
export const RISK_POLICY = {
  tiers: [   // confidence → base risk %, before the condition adjustments
    { id: 'very_high', min: 85, pct: 1.5 },
    { id: 'high', min: 75, pct: 1.0 },
    { id: 'medium', min: 68, pct: 0.6 },
    { id: 'low', min: MIN_CONFIDENCE, pct: 0.3 },
  ],
  SAFE_MAX: 2,     // the normal operating ceiling; anything above it is flagged as above the safe policy
  HARD_MAX: 5,     // no configuration can raise the per-trade risk above this
  ABS_LIMIT: 25,   // the theoretical top of the scale: shown in the policy, never assigned automatically
  MIN: 0.1,
};
// How long an unfilled limit waits, and how long an entered trade is followed before it is closed at the market (in bars).
export const PENDING_BARS = { '1h': 18, '4h': 12, '1D': 5 };
export const MAX_HOLD_BARS = { '1h': 120, '4h': 60, '1D': 30 };
// Practical limit distance (a swing entry must not wait for a far-away level): ATR of the signal's frame AND % of price.
const LIMIT_CAP = { forex: { atr: 1.6, pct: 0.8 }, metal: { atr: 1.6, pct: 1.5 }, index: { atr: 1.6, pct: 1.5 }, crypto: { atr: 1.6, pct: 3 }, energy: { atr: 1.6, pct: 2.5 } };

const r8 = (v) => (Number.isFinite(v) ? Math.round(v * 1e8) / 1e8 : v);
const r2 = (v) => (Number.isFinite(v) ? Math.round(v * 100) / 100 : v);
const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
const last = (arr) => { for (let i = arr.length - 1; i >= 0; i--) if (arr[i] != null) return arr[i]; return null; };

/** Platform pip convention (src/services/pips.js): 10 points on forex / metals / crypto, 1 on indices. */
export const pipOf = (inst) => (inst?.pointSize || 0.01) * (inst?.type === 'index' ? 1 : 10);
export const unitOf = (inst) => (inst?.type === 'index' ? 'points' : 'pips');
/** Price distance → pips (points on indices), one decimal, with the platform's pip size. */
export const pipsOf = (dist, inst) => Math.round((dist / pipOf(inst)) * 10) / 10;
export const assetOf = (inst) => ({ crypto: 'crypto', metal: 'metal', energy: 'energy', index: 'index', forex: 'forex' }[inst?.type] || 'index');

/** MACD (12, 26, 9) → { macd, signal, hist } arrays. */
export function macd(closes, f = 12, s = 26, sig = 9) {
  const a = ema(closes, f); const b = ema(closes, s);
  const line = closes.map((_, i) => (a[i] != null && b[i] != null ? a[i] - b[i] : null));
  const first = line.findIndex((v) => v != null);
  const sigLine = new Array(closes.length).fill(null);
  if (first >= 0) { const e = ema(line.slice(first), sig); e.forEach((v, k) => { sigLine[first + k] = v; }); }
  return { macd: line, signal: sigLine, hist: line.map((v, i) => (v != null && sigLine[i] != null ? v - sigLine[i] : null)) };
}

/** The candles that are CLOSED at nowMs (a forming candle is never analysed). */
export function closedOnly(candles, tfSec, nowMs) {
  const n = candles.length; if (!n) return candles;
  return candles[n - 1].time + tfSec <= Math.floor(nowMs / 1000) ? candles : candles.slice(0, -1);
}

/** Technical confirmation for a direction → { checks: [{ id, ok, w, note }], ind } (positive weights add, negative take). */
export function technicals(cs, dir) {
  const closes = cs.map((c) => c.close); const px = closes.at(-1); const long = dir === 'long';
  const e20 = last(ema(closes, 20)); const e50 = last(ema(closes, 50)); const e100 = last(ema(closes, 100)); const e200 = last(ema(closes, 200));
  const rs = rsi(closes, 14); const r = last(rs); const rPrev = rs.at(-4) ?? r;
  const m = macd(closes); const h = m.hist.at(-1); const hPrev = m.hist.at(-3);
  const a = atr(cs, 14); const aNow = last(a);
  const atrPct = cs.slice(-100).map((_, k) => a[cs.length - 100 + k]).filter((v) => v != null).sort((x, y) => x - y);
  const atrMed = atrPct[Math.floor(atrPct.length / 2)] || aNow;
  const vols = cs.map((c) => c.volume).filter((v) => Number.isFinite(v) && v > 0);
  const hasVol = vols.length >= cs.length * 0.8;
  const v10 = hasVol ? cs.slice(-10).reduce((s, c) => s + (c.volume || 0), 0) / 10 : null;
  const v50 = hasVol ? cs.slice(-50).reduce((s, c) => s + (c.volume || 0), 0) / 50 : null;
  const stack = long ? e20 > e50 && e50 > e100 && e100 > e200 : e20 < e50 && e50 < e100 && e100 < e200;
  const side200 = long ? px > e200 : px < e200;
  const checks = [
    { id: 'ema_stack', ok: Boolean(stack), w: stack ? 8 : 0 },
    { id: 'ema200', ok: Boolean(side200), w: side200 ? 6 : -6 },
    { id: 'rsi', ok: long ? r >= 40 && r <= 68 : r <= 60 && r >= 32, w: (long ? r >= 40 && r <= 68 : r <= 60 && r >= 32) ? 5 : (long ? r > 75 : r < 25) ? -6 : 0, note: r2(r) },
    { id: 'rsi_turn', ok: long ? r > rPrev : r < rPrev, w: (long ? r > rPrev : r < rPrev) ? 3 : 0 },
    { id: 'macd', ok: long ? h > 0 || (h > hPrev) : h < 0 || (h < hPrev), w: (long ? h > 0 : h < 0) ? 5 : (long ? h > hPrev : h < hPrev) ? 3 : -3, note: r8(h) },
    { id: 'volume', ok: hasVol ? v10 >= v50 : null, w: hasVol ? (v10 >= 1.1 * v50 ? 4 : v10 >= v50 ? 2 : -1) : 0, note: hasVol ? r2(v10 / v50) : 'no_volume' },
  ];
  const volRatio = atrMed ? aNow / atrMed : 1;
  return { checks, ind: { px, e20: r8(e20), e50: r8(e50), e100: r8(e100), e200: r8(e200), rsi: r2(r), macdHist: r8(h), atr: r8(aNow), volRatio: r2(volRatio), hasVol } };
}

/** Measured results of the channel's OWN closed signals (same market or same frame) → adjustment in confidence points. */
export function historyEdge(signals, symbol, tf) {
  const closed = (signals || []).filter((s) => FINAL_STATUSES.includes(s.status) && s.status !== 'cancelled' && s.filledAt);
  const pick = (f) => { const l = closed.filter(f); const w = l.filter((s) => (s.realizedR ?? 0) > 0).length; return { n: l.length, wr: l.length ? w / l.length : null }; };
  const m = pick((s) => s.symbol === symbol && s.tf === tf);
  const all = pick(() => true);
  const use = m.n >= 15 ? m : all.n >= 30 ? all : null;
  if (!use) return { pts: 0, n: m.n, wr: m.wr, basis: 'not_enough' };
  return { pts: Math.round(clamp((use.wr - 0.5) * 30, -8, 8)), n: use.n, wr: r2(use.wr), basis: use === m ? 'market_tf' : 'channel' };
}

/**
 * Confidence (0–100) of a setup from the SMC reading, the technical checks, the higher frames, volatility, stop quality, news
 * and the channel's own record. → { score, parts: [{ id, pts }] }
 */
export function confidenceOf({ smc, tech, news, hist, entryAtr, stopAtr, tf }) {
  const parts = []; const add = (id, pts) => { if (pts) parts.push({ id, pts }); };
  const ok = (id) => smc.checks.find((c) => c.id === id)?.ok;
  add('base', 30);
  add('htf_bias', ok('bias') ? (smc.htfConflict === 'minor' ? 6 : 12) : -10);
  add('structure', ok('structure') ? 7 : 0);
  add('sweep', ok('sweep') ? 7 : 0);
  add('mss', ok('mss') ? 6 : 0);
  const poi = smc.zones?.poi; add('poi', poi ? (poi.kind === 'OB' || poi.kind === 'BB' ? 5 : 3) + (poi.withFvg ? 2 : 0) : 0);
  add('premium_discount', ok('pd') ? 4 : -6);
  add('ote', ok('ote') ? 4 : 0);
  for (const c of tech.checks) add(c.id, c.w);
  const rr = smc.plan?.rrMain ?? 0; add('rr', rr >= 4 ? 5 : rr >= 3 ? 3 : rr >= 2.5 ? 1 : -4);
  add('stop_quality', stopAtr >= 0.8 && stopAtr <= 3 ? 4 : stopAtr > 4.5 ? -5 : 0);
  add('volatility', tech.ind.volRatio > 2.2 ? -12 : tech.ind.volRatio > 1.6 ? -5 : tech.ind.volRatio < 0.45 ? -4 : 2);
  add('news', news?.level === 'high' ? -15 : news?.level === 'soon' ? -6 : news?.known === false ? -2 : 0);
  add('entry_distance', entryAtr > 1.2 ? -3 : 0);
  add('history', hist?.pts || 0);
  add('timeframe', tf === '1D' ? 2 : tf === '4h' ? 1 : 0);
  const score = Math.round(clamp(parts.reduce((s, p) => s + p.pts, 0), 0, 100));
  return { score, parts };
}

/**
 * The AI's risk % for ONE recommendation. Never above the configured ceiling, never above HARD_MAX, never automatically 25 %.
 * opts: { confidence, volRatio, news, stopAtr, openRiskPct (the channel's live exposure on the same market / direction), maxPct }
 * → { pct, tier, reasons: [code], aboveSafe, policyMax }  or { pct: 0, tier: 'reject' } below the threshold.
 */
export function chooseRisk({ confidence, volRatio = 1, news = null, stopAtr = 1, openRiskPct = 0, maxPct = RISK_POLICY.SAFE_MAX } = {}) {
  const ceiling = clamp(Number(maxPct) || RISK_POLICY.SAFE_MAX, RISK_POLICY.MIN, RISK_POLICY.HARD_MAX);
  const tier = RISK_POLICY.tiers.find((t) => confidence >= t.min);
  if (!tier) return { pct: 0, tier: 'reject', reasons: ['below_threshold'], aboveSafe: false, policyMax: ceiling };
  const reasons = [`tier_${tier.id}`]; let pct = tier.pct;
  if (volRatio > 1.6) { pct *= 0.7; reasons.push('high_volatility'); }
  if (news?.level === 'soon') { pct *= 0.6; reasons.push('news_soon'); }
  if (news?.level === 'high') { pct *= 0.4; reasons.push('news_now'); }
  if (stopAtr > 3) { pct *= 0.8; reasons.push('wide_stop'); }
  if (openRiskPct > 0) { const room = Math.max(0, ceiling * 1.5 - openRiskPct); if (room < pct) { pct = room; reasons.push('exposure_cap'); } }
  if (pct > ceiling) { pct = ceiling; reasons.push('policy_cap'); }
  pct = Math.round(pct * 100) / 100;
  if (pct < RISK_POLICY.MIN) return { pct: 0, tier: 'reject', reasons: [...reasons, 'no_risk_room'], aboveSafe: false, policyMax: ceiling };
  return { pct, tier: tier.id, reasons, aboveSafe: pct > RISK_POLICY.SAFE_MAX, policyMax: ceiling };
}

/** Is the trade's geometry valid? Stop on the losing side, targets in order on the winning side. */
export function levelsValid({ direction, entry, stop, targets }) {
  const s = direction === 'buy' ? 1 : -1;
  if (![entry, stop, ...targets].every(Number.isFinite) || targets.length !== 3) return false;
  if ((entry - stop) * s <= 0) return false;
  for (let k = 0; k < 3; k++) if ((targets[k] - (k ? targets[k - 1] : entry)) * s <= 0) return false;
  return true;
}

/** Same market and direction already live, or the same setup closed less than two bars ago → duplicate. */
export function isDuplicate(signals, cand, sec, nowMs) {
  return (signals || []).some((s) => s.symbol === cand.symbol && s.direction === cand.direction
    && (LIVE_STATUSES.includes(s.status) || (s.tf === cand.tf && (s.closedAt || s.createdAt) > nowMs - 2 * sec * 1000)));
}

/**
 * Evaluate ONE market on ONE closed candle of one timeframe.
 * → { state: 'ok'|'no_trade'|'stale'|'closed'|'unavailable'|'insufficient', reason, signal|null, barTime, analysis }
 */
export function evaluateSwing({ market, inst, tf, ds, htf = null, quote = null, calendar = null, nowMs = Date.now(), signals = [], maxRiskPct = RISK_POLICY.SAFE_MAX }) {
  const sec = TF_SEC[tf];
  if (!sec) return { state: 'unavailable', reason: 'timeframe_not_swing', signal: null };
  if (!ds || ds.mode !== 'live' || !Array.isArray(ds.candles)) return { state: 'unavailable', reason: ds?.mode === 'demo' ? 'demo_data' : 'no_data', signal: null };
  const cs = closedOnly(ds.candles, sec, nowMs);
  if (cs.length < 220) return { state: 'insufficient', reason: 'need_220_closed_candles', signal: null, barTime: cs.at(-1)?.time };
  const barTime = cs.at(-1).time;
  // Freshness: the newest closed candle must be the one that just closed (one bar of slack; Daily allows a weekend gap).
  const age = Math.floor(nowMs / 1000) - (barTime + sec);
  const slack = tf === '1D' ? 3 * 86400 : 2 * sec;
  if (age > slack) return { state: inst?.type === 'crypto' ? 'stale' : 'closed', reason: 'no_fresh_candle', signal: null, barTime };
  if (!quote || !Number.isFinite(quote.price) || nowMs - (quote.at || 0) > 15 * 60_000) return { state: 'stale', reason: 'no_live_quote', signal: null, barTime };
  if (cs.some((c, i) => i > cs.length - 30 && !(c.high >= Math.max(c.open, c.close) && c.low <= Math.min(c.open, c.close) && c.low > 0))) return { state: 'stale', reason: 'bad_candles', signal: null, barTime };

  const asset = assetOf(inst);
  const news = calendar ? newsRisk(market.symbol || inst.symbol, calendar.events || [], nowMs, { aheadMin: 120, soonMin: 24 * 60, afterMin: 60 }) : { level: 'none', known: false };
  const smc = analyzeSmcIct(cs, { style: 'swing', execution: 'limit', asset, symbol: inst.symbol, tfSec: sec, htf, news, capital: 0, maxOpen: 20, exposure: { open: 0 }, htfMode: 'tiered' });
  const analysis = { smc: { verdict: smc.verdict, reasons: smc.reasons, direction: smc.direction, bias: smc.bias?.bias ?? null, trend: smc.trend, checks: (smc.checks || []).map((c) => ({ id: c.id, ok: c.ok })) } };
  if (smc.verdict !== 'trade' || !smc.plan) return { state: 'no_trade', reason: smc.reasons?.[0] || smc.verdict, signal: null, barTime, analysis };
  const dir = smc.plan.direction; const direction = dir === 'long' ? 'buy' : 'sell';
  const tech = technicals(cs, dir); analysis.tech = tech;
  const a = tech.ind.atr; const price = quote.price;
  const plan = smc.plan; const entryType = plan.execution === 'market' ? 'market' : 'limit';
  // A market entry is taken at the LIVE price (never an older close); a limit keeps its level and must still be on the right side.
  let entry = entryType === 'market' ? price : plan.entry;
  if (entryType === 'limit' && (direction === 'buy' ? price <= entry : price >= entry)) entry = price;   // already through the level
  const type = entryType === 'limit' && entry !== price ? 'limit' : 'market';
  const cap = LIMIT_CAP[asset] || LIMIT_CAP.index;
  const dist = Math.abs(entry - price);
  if (type === 'limit' && (dist > cap.atr * a || dist / price * 100 > cap.pct)) return { state: 'no_trade', reason: 'entry_too_far', signal: null, barTime, analysis };
  const stop = plan.stop; const risk = Math.abs(entry - stop);
  const targets = plan.targets.slice(0, 3);
  if (!levelsValid({ direction, entry, stop, targets })) return { state: 'no_trade', reason: 'invalid_levels', signal: null, barTime, analysis };
  const stopAtr = risk / a; const entryAtr = dist / a;
  const hist = historyEdge(signals, inst.symbol, tf);
  const conf = confidenceOf({ smc, tech, news, hist, entryAtr, stopAtr, tf });
  analysis.confidence = conf;
  if (conf.score < MIN_CONFIDENCE) return { state: 'no_trade', reason: 'low_confidence', signal: null, barTime, analysis };
  const openRiskPct = (signals || []).filter((s) => LIVE_STATUSES.includes(s.status) && s.symbol === inst.symbol && s.direction === direction).reduce((t, s) => t + (s.riskPct || 0), 0);
  const rk = chooseRisk({ confidence: conf.score, volRatio: tech.ind.volRatio, news, stopAtr, openRiskPct, maxPct: maxRiskPct });
  if (rk.tier === 'reject') return { state: 'no_trade', reason: rk.reasons.at(-1), signal: null, barTime, analysis };
  const cand = { symbol: inst.symbol, direction, tf };
  if (isDuplicate(signals, cand, sec, nowMs)) return { state: 'no_trade', reason: 'duplicate', signal: null, barTime, analysis };
  const prec = inst.precision ?? 5; const rnd = (v) => Number(v.toFixed(prec));
  const sig = {
    id: `sw_${inst.symbol}_${tf}_${barTime}_${direction}`,
    channel: 'swing', strategy: SWING_STRATEGY, engine: SWING_ENGINE_VERSION,
    market: market.id, name: market.name || inst.symbol, symbol: inst.symbol, asset, tf, direction, entryType: type,
    entry: rnd(entry), stop: rnd(stop), targets: targets.map(rnd), initialStop: rnd(stop),
    rr: targets.map((t) => r2(Math.abs(t - entry) / risk)), pipsTo: { stop: pipsOf(risk, inst), targets: targets.map((t) => pipsOf(Math.abs(t - entry), inst)) }, unit: unitOf(inst),
    confidence: conf.score, confidenceParts: conf.parts, riskPct: rk.pct, riskTier: rk.tier, riskReasons: rk.reasons, riskAboveSafe: rk.aboveSafe, riskPolicyMax: rk.policyMax,
    confirmations: [...smc.checks.filter((c) => c.ok && ['bias', 'structure', 'sweep', 'mss', 'pd', 'ote'].includes(c.id)).map((c) => c.id), ...(smc.zones?.poi ? [`poi_${smc.zones.poi.kind.toLowerCase()}`] : []), ...tech.checks.filter((c) => c.ok).map((c) => c.id)],
    news: news?.level || 'none', volRatio: tech.ind.volRatio, atr: r8(a),
    createdAt: nowMs, barTime, status: type === 'market' ? 'active' : 'pending',
    filledAt: type === 'market' ? nowMs : null, fillPrice: type === 'market' ? rnd(price) : null,
    expiresAt: type === 'limit' ? nowMs + PENDING_BARS[tf] * sec * 1000 : null,
    maxHoldUntil: nowMs + MAX_HOLD_BARS[tf] * sec * 1000,
    price: rnd(price), priceAt: quote.at || nowMs, hits: 0, realizedR: null, realizedPips: null, closedAt: null, closeReason: null,
    executed: false,   // a tracked recommendation, not a broker execution (no account fill is verified)
    source: ds.source || null, pointSize: inst.pointSize, pip: pipOf(inst), precision: prec,
  };
  return { state: 'ok', reason: null, signal: sig, barTime, analysis };
}

/**
 * Follow one recommendation on 1-minute candles + the live quote. Management (shown in the page): one third closed at each
 * target, the stop moves to the entry once TP1 is hit. A candle that touches both the stop and a target counts as the stop.
 * Mutates and returns the signal; returns the list of status changes (for notifications).
 */
export function trackSwing(s, candles, { nowMs = Date.now(), price = null, priceAt = null, pip = null } = {}) {
  const events = []; if (!LIVE_STATUSES.includes(s.status)) return events;
  const long = s.direction === 'buy'; const sgn = long ? 1 : -1;
  const risk = Math.abs(s.entry - s.initialStop);
  const set = (st, extra = {}) => { s.status = st; Object.assign(s, extra); events.push({ status: st, at: extra.at || nowMs }); };
  for (const c of candles || []) {
    if (!LIVE_STATUSES.includes(s.status)) break;
    if (c.time + 60 <= Math.floor(s.createdAt / 1000)) continue;
    if (s.trackedTo && c.time < s.trackedTo) continue;   // each candle is walked once (the newest, still forming one again)
    s.trackedTo = c.time;
    if (s.status === 'pending') {
      if (s.expiresAt && c.time * 1000 >= s.expiresAt) { set('cancelled', { closedAt: s.expiresAt, closeReason: 'expired', at: s.expiresAt }); break; }
      const touched = long ? c.low <= s.entry : c.high >= s.entry;
      if (!touched) continue;
      set('active', { filledAt: Math.max(s.createdAt, c.time * 1000), fillPrice: s.entry, at: c.time * 1000 });
    }
    const stopNow = s.hits >= 1 ? s.entry : s.initialStop;
    const hitStop = long ? c.low <= stopNow : c.high >= stopNow;
    if (hitStop) {
      const partsR = [s.rr[0], s.rr[1]].slice(0, s.hits).reduce((t, r) => t + r / 3, 0);
      const rest = (3 - s.hits) / 3 * (s.hits >= 1 ? 0 : -1);
      const R = r2(partsR + rest);
      set(s.hits >= 1 ? 'closed' : 'sl', { closedAt: c.time * 1000, closeReason: s.hits >= 1 ? 'breakeven_after_tp' : 'stop', realizedR: R, at: c.time * 1000 });
      break;
    }
    while (s.hits < 3 && (long ? c.high >= s.targets[s.hits] : c.low <= s.targets[s.hits])) {
      s.hits += 1;
      if (s.hits === 3) { const R = r2((s.rr[0] + s.rr[1] + s.rr[2]) / 3); set('tp3', { closedAt: c.time * 1000, closeReason: 'tp3', realizedR: R, at: c.time * 1000 }); break; }
      set(s.hits === 1 ? 'tp1' : 'tp2', { at: c.time * 1000 });
    }
  }
  if (LIVE_STATUSES.includes(s.status) && s.status !== 'pending' && s.maxHoldUntil && nowMs >= s.maxHoldUntil && Number.isFinite(price)) {
    const R = r2([s.rr[0], s.rr[1]].slice(0, s.hits).reduce((t, r) => t + r / 3, 0) + ((3 - s.hits) / 3) * ((price - s.entry) * sgn / risk));
    set('closed', { closedAt: nowMs, closeReason: 'max_hold', realizedR: R });
  }
  if (s.status === 'pending' && s.expiresAt && nowMs >= s.expiresAt) set('cancelled', { closedAt: s.expiresAt, closeReason: 'expired' });
  if (Number.isFinite(price)) { s.price = price; s.priceAt = priceAt || nowMs; }
  // Floating (open part, from the live price) and realized (closed parts) in R and in pips / points.
  const unit = pip || s.pip || 1;
  const openPart = s.status === 'pending' || !LIVE_STATUSES.includes(s.status) ? 0 : (3 - s.hits) / 3;
  const realizedR = s.realizedR ?? r2([s.rr[0], s.rr[1], s.rr[2]].slice(0, s.hits).reduce((t, r) => t + r / 3, 0));
  s.realizedR = FINAL_STATUSES.includes(s.status) ? s.realizedR : (s.hits ? realizedR : null);
  s.floatingR = openPart && Number.isFinite(s.price) ? r2(openPart * ((s.price - s.entry) * sgn / risk)) : 0;
  s.livePips = s.status !== 'pending' && Number.isFinite(s.price) ? Math.round(((s.price - s.entry) * sgn / unit) * 10) / 10 : null;
  s.realizedPips = s.realizedR != null ? Math.round((s.realizedR * risk / unit) * 10) / 10 : null;
  return events;
}

/** Statistics from the channel's own recorded signals only (nothing assumed). */
export function swingSummary(signals) {
  const all = signals || [];
  const done = all.filter((s) => FINAL_STATUSES.includes(s.status) && s.status !== 'cancelled' && s.filledAt);
  const wins = done.filter((s) => (s.realizedR ?? 0) > 0); const losses = done.filter((s) => (s.realizedR ?? 0) < 0);
  const group = (key) => { const m = {}; for (const s of done) { const k = s[key]; const g = (m[k] ||= { n: 0, wins: 0, pips: 0, r: 0 }); g.n += 1; g.wins += (s.realizedR ?? 0) > 0 ? 1 : 0; g.pips = r2(g.pips + (s.realizedPips || 0)); g.r = r2(g.r + (s.realizedR || 0)); } return m; };
  const rrPlanned = all.filter((s) => s.rr?.length).map((s) => s.rr[2]);
  const tiers = {}; for (const s of all) tiers[s.riskTier] = (tiers[s.riskTier] || 0) + 1;
  return {
    total: all.length,
    pending: all.filter((s) => s.status === 'pending').length,
    active: all.filter((s) => ['active', 'tp1', 'tp2'].includes(s.status)).length,
    completed: done.length, cancelled: all.filter((s) => s.status === 'cancelled').length,
    wins: wins.length, losses: losses.length, breakeven: done.length - wins.length - losses.length,
    winRate: done.length ? r2(wins.length / done.length) : null,
    realizedPips: r2(done.reduce((t, s) => t + (s.realizedPips || 0), 0)),
    realizedR: r2(done.reduce((t, s) => t + (s.realizedR || 0), 0)),
    avgPlannedRR: rrPlanned.length ? r2(rrPlanned.reduce((a, b) => a + b, 0) / rrPlanned.length) : null,
    avgRiskPct: all.length ? r2(all.reduce((t, s) => t + (s.riskPct || 0), 0) / all.length) : null,
    byMarket: group('symbol'), byTf: group('tf'), byStrategy: group('strategy'), riskTiers: tiers,
  };
}
