// v348 Order Flow engine (pure, no network): builds footprint candles from REAL exchange trades (each trade carries its
// aggressor side: buyer lifting the ask or seller hitting the bid), the volume profile (POC / value area), delta and CVD,
// diagonal imbalances, and the order-flow setups the page alerts on. Liquidity levels come from the real order book.
// Nothing here is simulated: with no trades there is no footprint.

const r8 = (v) => Math.round(v * 1e8) / 1e8;
export const priceKey = (p, tick) => r8(Math.floor(p / tick + 1e-9) * tick);

/** A tick (row height) that gives about `rows` rows over a typical candle range. */
export function autoTick(price, tfSec) {
  const pct = tfSec <= 60 ? 0.00012 : tfSec <= 300 ? 0.0003 : 0.0007;
  const raw = Math.max(1e-8, price * pct); const k = 10 ** Math.floor(Math.log10(raw)); const m = raw / k;
  return +((m < 1.5 ? 1 : m < 2.25 ? 2 : m < 3.5 ? 2.5 : m < 7.5 ? 5 : 10) * k).toPrecision(6);
}

export class Footprint {
  constructor({ tfSec = 60, tick = 1, maxCandles = 240 } = {}) { this.tfSec = tfSec; this.tick = tick; this.max = maxCandles; this.candles = []; this.profile = new Map(); this.cvd = 0; this.lastId = 0; this.big = []; this.sizes = []; }
  /** Add one real trade { id, price, qty, time (ms), buy }. Old / duplicate ids are ignored. Returns the candle. */
  add(t) {
    if (!(t.qty > 0) || !(t.price > 0)) return null;
    if (t.id != null) { if (t.id <= this.lastId) return null; this.lastId = t.id; }
    const open = Math.floor(t.time / 1000 / this.tfSec) * this.tfSec;
    let c = this.candles.at(-1);
    if (!c || c.time < open) {
      if (c && open < c.time) return null;
      c = { time: open, open: t.price, high: t.price, low: t.price, close: t.price, buy: 0, sell: 0, delta: 0, minDelta: 0, maxDelta: 0, rows: new Map(), trades: 0, cvdOpen: this.cvd };
      this.candles.push(c); if (this.candles.length > this.max) this.candles.shift();
    } else if (open < c.time) {   // a late trade for an older candle (rare): add it there
      c = this.candles.find((x) => x.time === open); if (!c) return null;
    }
    const k = priceKey(t.price, this.tick);
    const row = c.rows.get(k) || { bid: 0, ask: 0 };
    if (t.buy) { row.ask += t.qty; c.buy += t.qty; this.cvd += t.qty; } else { row.bid += t.qty; c.sell += t.qty; this.cvd -= t.qty; }
    c.rows.set(k, row); c.trades++;
    c.high = Math.max(c.high, t.price); c.low = Math.min(c.low, t.price); c.close = t.price;
    c.delta = c.buy - c.sell; c.minDelta = Math.min(c.minDelta, c.delta); c.maxDelta = Math.max(c.maxDelta, c.delta); c.cvd = this.cvd;
    const p = this.profile.get(k) || { bid: 0, ask: 0 }; if (t.buy) p.ask += t.qty; else p.bid += t.qty; this.profile.set(k, p);
    // large prints: the top 1% of recent trade sizes (kept on a rolling sample)
    this.sizes.push(t.qty); if (this.sizes.length > 4000) this.sizes.splice(0, 1000);
    if (this.sizes.length >= 200 && t.qty >= this.bigCut()) { this.big.push({ ...t }); if (this.big.length > 60) this.big.shift(); }
    return c;
  }
  bigCut() { if (this._cutAt === this.sizes.length) return this._cut; const s = [...this.sizes].sort((a, b) => a - b); this._cut = s[Math.floor(s.length * 0.99)]; this._cutAt = this.sizes.length; return this._cut; }
  /** Rebuild with another tick or timeframe from a stored trade list. */
  static from(trades, opts) { const f = new Footprint(opts); for (const t of trades) f.add(t); return f; }
}

/** Point of control of one candle → price key of the row with the most volume. */
export function candlePoc(c) { let best = null; let v = -1; for (const [k, r] of c.rows) { const s = r.bid + r.ask; if (s > v) { v = s; best = k; } } return best; }

/**
 * Diagonal imbalances in one candle (the standard footprint reading): ask at price P against bid one tick BELOW (buyers),
 * bid at P against ask one tick ABOVE (sellers), with ratio ≥ `ratio` and a minimum size. → Map(key → 'buy'|'sell')
 */
export function imbalances(c, tick, { ratio = 3, minQty = 0 } = {}) {
  const out = new Map();
  for (const [k, r] of c.rows) {
    const below = c.rows.get(r8(k - tick)); const above = c.rows.get(r8(k + tick));
    if (r.ask > minQty && r.ask >= ratio * Math.max(below?.bid || 0, 1e-12) && (below?.bid || 0) > 0) out.set(k, 'buy');
    else if (r.bid > minQty && r.bid >= ratio * Math.max(above?.ask || 0, 1e-12) && (above?.ask || 0) > 0) out.set(k, 'sell');
  }
  return out;
}
/** 3+ consecutive imbalance rows of one side → [{ side, from, to, n }] */
export function stacked(c, tick, opts) {
  const im = imbalances(c, tick, opts); const keys = [...im.keys()].sort((a, b) => a - b); const out = []; let run = null;
  for (const k of keys) {
    if (run && im.get(k) === run.side && Math.abs(k - run.to - tick) < tick / 2) { run.to = k; run.n++; }
    else { if (run && run.n >= 3) out.push(run); run = { side: im.get(k), from: k, to: k, n: 1 }; }
  }
  if (run && run.n >= 3) out.push(run);
  return out;
}

/** Volume profile → { poc, vah, val, total, rows: [[key, bid, ask]] (high → low) } with a `va` (0.7) value area. */
export function volumeProfile(profile, va = 0.7) {
  const rows = [...profile.entries()].map(([k, r]) => [k, r.bid, r.ask]).sort((a, b) => b[0] - a[0]);
  if (!rows.length) return null;
  const total = rows.reduce((t, r) => t + r[1] + r[2], 0);
  let pi = 0; rows.forEach((r, i) => { if (r[1] + r[2] > rows[pi][1] + rows[pi][2]) pi = i; });
  let lo = pi; let hi = pi; let acc = rows[pi][1] + rows[pi][2];
  while (acc < total * va && (lo < rows.length - 1 || hi > 0)) {
    const up = hi > 0 ? rows[hi - 1][1] + rows[hi - 1][2] : -1; const dn = lo < rows.length - 1 ? rows[lo + 1][1] + rows[lo + 1][2] : -1;
    if (up >= dn) { hi--; acc += up; } else { lo++; acc += dn; }
  }
  return { poc: rows[pi][0], vah: rows[hi][0], val: rows[lo][0], total, rows };
}

/** Liquidity levels from a real order book snapshot { bids: [[p,q]], asks } bucketed by `step` → the biggest resting walls. */
export function liquidityLevels(book, mid, step, { top = 5, rangePct = 1.5 } = {}) {
  const lo = mid * (1 - rangePct / 100); const hi = mid * (1 + rangePct / 100); const bins = { bid: new Map(), ask: new Map() };
  const add = (side, [p, q]) => { p = +p; q = +q; if (!(p >= lo && p <= hi) || !(q > 0)) return; const k = priceKey(p, step); bins[side].set(k, (bins[side].get(k) || 0) + q); };
  (book?.bids || []).forEach((x) => add('bid', x)); (book?.asks || []).forEach((x) => add('ask', x));
  const pick = (side) => { const all = [...bins[side].entries()]; const avg = all.reduce((t, [, q]) => t + q, 0) / Math.max(1, all.length);
    return all.sort((a, b) => b[1] - a[1]).slice(0, top).map(([price, qty]) => ({ side, price, qty: r8(qty), x: r8(qty / (avg || 1)), distPct: r8(((price - mid) / mid) * 100) })); };
  return { bids: pick('bid'), asks: pick('ask') };
}

/**
 * Order-flow setups on the last CLOSED candle (alerts):
 *  • stacked imbalance (3+ rows) — initiative buyers / sellers
 *  • delta divergence — new high with negative delta (or new low with positive delta): weak push, possible reversal
 *  • absorption — very high volume and heavy one-sided delta, but the candle closes against that side
 *  • wall test — the close is within 0.1% of a big resting wall (liquidity level)
 * → [{ id, side: 'buy'|'sell', strength 1-3, price, at, detail }]
 */
export function setups(fp, { walls = null, lookback = 20 } = {}) {
  const cs = fp.candles; if (cs.length < 3) return [];
  const c = cs.at(-2); const prev = cs.slice(Math.max(0, cs.length - 2 - lookback), -2); if (!prev.length) return [];
  const out = []; const vol = c.buy + c.sell; const avgVol = prev.reduce((t, x) => t + x.buy + x.sell, 0) / prev.length;
  for (const s of stacked(c, fp.tick)) out.push({ id: `stack:${c.time}:${s.side}`, kind: 'stack', side: s.side, strength: s.n >= 5 ? 3 : s.n >= 4 ? 2 : 1, price: s.side === 'buy' ? s.from : s.to, at: c.time, detail: { rows: s.n } });
  const hiPrev = Math.max(...prev.map((x) => x.high)); const loPrev = Math.min(...prev.map((x) => x.low));
  if (c.high > hiPrev && c.delta < 0) out.push({ id: `div:${c.time}:sell`, kind: 'divergence', side: 'sell', strength: c.close < c.open ? 2 : 1, price: c.high, at: c.time, detail: { delta: r8(c.delta) } });
  if (c.low < loPrev && c.delta > 0) out.push({ id: `div:${c.time}:buy`, kind: 'divergence', side: 'buy', strength: c.close > c.open ? 2 : 1, price: c.low, at: c.time, detail: { delta: r8(c.delta) } });
  if (vol > 2 * avgVol && Math.abs(c.delta) > 0.25 * vol) {
    if (c.delta < 0 && c.close >= c.open) out.push({ id: `abs:${c.time}:buy`, kind: 'absorption', side: 'buy', strength: vol > 3 * avgVol ? 3 : 2, price: c.low, at: c.time, detail: { volX: r8(vol / avgVol) } });
    if (c.delta > 0 && c.close <= c.open) out.push({ id: `abs:${c.time}:sell`, kind: 'absorption', side: 'sell', strength: vol > 3 * avgVol ? 3 : 2, price: c.high, at: c.time, detail: { volX: r8(vol / avgVol) } });
  }
  if (walls) for (const w of [...walls.bids, ...walls.asks]) if (w.x >= 3 && Math.abs(c.close - w.price) / c.close < 0.001) out.push({ id: `wall:${c.time}:${w.price}`, kind: 'wall', side: w.side === 'bid' ? 'buy' : 'sell', strength: w.x >= 6 ? 2 : 1, price: w.price, at: c.time, detail: { x: w.x } });
  return out;
}
