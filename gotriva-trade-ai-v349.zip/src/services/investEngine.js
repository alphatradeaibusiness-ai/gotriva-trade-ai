// v347 Investment section — pure analysis (no network): momentum / trend from real daily candles, a fundamentals score from the
// company's reported metrics, and the AI news-sentiment score, combined into one "ready trade" with a clear BUY / SELL / WAIT,
// entry, stop, two targets, an exit rule, a confidence, and the evidence behind every part (so the trade is documented).
// Parts that have no real data are left out of the score (their weight is shared out) and the trade says so. Nothing is invented.
import { ema, rsi, atr } from '../indicators/index.js';
import { macd } from './swingEngine.js';

const r2 = (v) => (Number.isFinite(v) ? Math.round(v * 100) / 100 : null);
const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
const lastOf = (a) => { for (let i = a.length - 1; i >= 0; i--) if (a[i] != null) return a[i]; return null; };

export const WATCH = [
  { s: 'AAPL', n: { ar: 'أبل', en: 'Apple' }, sector: 'tech' },
  { s: 'TSLA', n: { ar: 'تسلا', en: 'Tesla' }, sector: 'auto' },
  { s: 'NVDA', n: { ar: 'إنفيديا', en: 'NVIDIA' }, sector: 'tech' },
  { s: 'MSFT', n: { ar: 'مايكروسوفت', en: 'Microsoft' }, sector: 'tech' },
  { s: 'AMZN', n: { ar: 'أمازون', en: 'Amazon' }, sector: 'consumer' },
  { s: 'GOOGL', n: { ar: 'ألفابت (جوجل)', en: 'Alphabet' }, sector: 'tech' },
  { s: 'META', n: { ar: 'ميتا', en: 'Meta' }, sector: 'tech' },
  { s: 'NFLX', n: { ar: 'نتفليكس', en: 'Netflix' }, sector: 'media' },
];
export const isWatched = (s) => WATCH.some((w) => w.s === s);

/** Momentum and trend from DAILY candles (oldest → newest, closed bars). → { score -1..1, ind, checks[] } or null when too short. */
export function momentum(cs) {
  if (!Array.isArray(cs) || cs.length < 60) return null;
  const c = cs.map((x) => x.close); const px = c.at(-1);
  const e20 = lastOf(ema(c, 20)); const e50 = lastOf(ema(c, 50)); const e200 = cs.length >= 200 ? lastOf(ema(c, 200)) : null;
  const r = lastOf(rsi(c, 14)); const m = macd(c); const hist = m.hist; const h1 = lastOf(hist); const h0 = hist.at(-2);
  const a = lastOf(atr(cs, 14));
  const roc20 = c.length > 21 ? (px / c.at(-21) - 1) * 100 : null;
  const roc60 = c.length > 61 ? (px / c.at(-61) - 1) * 100 : null;
  const hi52 = Math.max(...cs.slice(-252).map((x) => x.high)); const lo52 = Math.min(...cs.slice(-252).map((x) => x.low));
  const checks = [];
  const add = (id, v, w) => checks.push({ id, v: r2(v), w });
  add('above_ema50', px - e50, px > e50 ? 0.2 : -0.2);
  if (e200 != null) add('above_ema200', px - e200, px > e200 ? 0.2 : -0.2);
  add('ema20_50', e20 - e50, e20 > e50 ? 0.15 : -0.15);
  add('rsi', r, r == null ? 0 : r > 75 ? -0.05 : r >= 55 ? 0.15 : r <= 25 ? 0.05 : r <= 45 ? -0.15 : 0);   // over-stretched readings are not chased
  add('macd_hist', h1, h1 == null ? 0 : h1 > 0 ? (h0 != null && h1 > h0 ? 0.15 : 0.08) : (h0 != null && h1 < h0 ? -0.15 : -0.08));
  if (roc20 != null) add('roc20', roc20, clamp(roc20 / 40, -0.15, 0.15));
  const score = clamp(checks.reduce((t, x) => t + x.w, 0), -1, 1);
  return { score: r2(score), checks, ind: { price: px, ema20: r2(e20), ema50: r2(e50), ema200: r2(e200), rsi: r2(r), macdHist: r2(h1), atr: r2(a), roc20: r2(roc20), roc60: r2(roc60), hi52, lo52, fromHighPct: r2((px / hi52 - 1) * 100) } };
}

/** Fundamentals score from the reported metrics (already normalised: fractions, not percents). → { score -1..1, notes[] } or null. */
export function fundamentals(f) {
  if (!f) return null;
  const notes = []; let s = 0; let n = 0;
  const add = (id, w, v) => { notes.push({ id, w, v: r2(v) }); s += w; n++; };
  if (Number.isFinite(f.revenueGrowth)) add('revenue_growth', f.revenueGrowth > 0.15 ? 0.25 : f.revenueGrowth > 0.05 ? 0.12 : f.revenueGrowth < 0 ? -0.2 : 0, f.revenueGrowth * 100);
  if (Number.isFinite(f.epsGrowth)) add('eps_growth', f.epsGrowth > 0.15 ? 0.2 : f.epsGrowth > 0 ? 0.08 : -0.2, f.epsGrowth * 100);
  if (Number.isFinite(f.netMargin)) add('net_margin', f.netMargin > 0.2 ? 0.15 : f.netMargin > 0.08 ? 0.06 : f.netMargin < 0 ? -0.2 : 0, f.netMargin * 100);
  if (Number.isFinite(f.pe)) add('pe', f.pe <= 0 ? -0.15 : f.pe > 80 ? -0.15 : f.pe > 45 ? -0.06 : f.pe < 25 ? 0.08 : 0, f.pe);
  if (Number.isFinite(f.debtToEquity)) add('debt_equity', f.debtToEquity > 2 ? -0.1 : f.debtToEquity < 0.6 ? 0.06 : 0, f.debtToEquity);
  if (!n) return null;
  return { score: r2(clamp(s, -1, 1)), notes };
}

const W = { tech: 0.45, news: 0.3, fund: 0.25 };
/**
 * The ready trade. inputs: { symbol, price, candles (daily, closed), fund (normalised metrics|null), sentiment ({ score -1..1, n }|null),
 * marketOpen } → { action: 'buy'|'sell'|'wait', entryType, entry, stop, targets[2], rr[2], confidence 0-100, horizon, exitRule,
 * parts: { tech, news, fund } (each with its score & weight or null), missing[] }.
 */
export function readyTrade({ price, candles, fund, sentiment }) {
  const tech = momentum(candles); const fd = fundamentals(fund);
  const news = sentiment && Number.isFinite(sentiment.score) && sentiment.n > 0 ? { score: r2(clamp(sentiment.score, -1, 1)) } : null;
  const parts = { tech: tech ? { score: tech.score } : null, news, fund: fd ? { score: fd.score } : null };
  const missing = Object.entries(parts).filter(([, v]) => !v).map(([k]) => k);
  if (!tech) return { action: 'wait', reason: 'no_chart_data', confidence: 0, parts, missing, tech: null, fund: fd };
  const wsum = Object.entries(parts).reduce((t, [k, v]) => t + (v ? W[k] : 0), 0);
  for (const [k, v] of Object.entries(parts)) if (v) v.weight = r2(W[k] / wsum);
  const composite = Object.entries(parts).reduce((t, [k, v]) => t + (v ? v.score * (W[k] / wsum) : 0), 0);
  const px = Number.isFinite(price) ? price : tech.ind.price; const a = tech.ind.atr || px * 0.02;
  // agreement: how many parts point the same way as the composite
  const dir = composite >= 0.22 ? 'buy' : composite <= -0.22 ? 'sell' : 'wait';
  const agree = Object.values(parts).filter(Boolean).filter((v) => Math.sign(v.score) === Math.sign(composite) && Math.abs(v.score) > 0.05).length;
  const have = Object.values(parts).filter(Boolean).length;
  let confidence = Math.round(clamp(Math.abs(composite) * 100 * 1.3, 0, 90) * (0.75 + 0.25 * (agree / Math.max(1, have))) * (have === 3 ? 1 : have === 2 ? 0.85 : 0.7));
  confidence = clamp(confidence, 0, 92);
  const out = { action: dir, composite: r2(composite), confidence, parts, missing, tech, fund: fd, horizon: 'weeks', atr: r2(a) };
  if (dir === 'wait') return { ...out, reason: 'mixed', exitRule: null };
  const long = dir === 'buy';
  // stretched far above (below) the 20-day average → a LIMIT back at it instead of chasing the price
  const stretched = long ? px - tech.ind.ema20 > 1.2 * a : tech.ind.ema20 - px > 1.2 * a;
  const entryType = stretched ? 'limit' : 'market';
  const entry = stretched ? tech.ind.ema20 : px;
  const stop = long ? entry - 2 * a : entry + 2 * a;
  const risk = Math.abs(entry - stop);
  let t1 = long ? entry + 2 * risk : entry - 2 * risk; const t2 = long ? entry + 3.5 * risk : entry - 3.5 * risk;
  if (long && tech.ind.hi52 > entry + risk && tech.ind.hi52 < t1) t1 = tech.ind.hi52;   // the 52-week high is the first natural target
  const targets = [t1, t2].map(r2);
  return {
    ...out, entryType, entry: r2(entry), stop: r2(stop), targets, rr: targets.map((t) => r2(Math.abs(t - entry) / risk)),
    exitRule: long ? 'close_below_ema50_or_stop' : 'close_above_ema50_or_stop',
  };
}

/** Plain HTML → short text (press releases come as HTML). */
export const stripHtml = (s, max = 400) => String(s || '').replace(/<[^>]*>/g, ' ').replace(/&nbsp;/g, ' ').replace(/&amp;/g, '&').replace(/&#39;|&apos;/g, "'").replace(/&quot;/g, '"').replace(/\s+/g, ' ').trim().slice(0, max);
